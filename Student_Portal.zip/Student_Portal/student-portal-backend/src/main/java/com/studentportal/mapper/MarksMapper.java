package com.studentportal.mapper;

import com.studentportal.dto.MarksDto;
import com.studentportal.entity.Marks;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface MarksMapper {

    @Mapping(source = "student.id", target = "studentId")
    @Mapping(source = "student.firstName", target = "studentName")
    @Mapping(source = "student.rollNumber", target = "rollNumber")
    @Mapping(source = "course.id", target = "courseId")
    @Mapping(source = "course.courseCode", target = "courseCode")
    @Mapping(source = "course.courseName", target = "courseName")
    MarksDto toDto(Marks marks);

    Marks toEntity(MarksDto marksDto);
    void updateEntityFromDto(MarksDto marksDto, @MappingTarget Marks marks);
}
