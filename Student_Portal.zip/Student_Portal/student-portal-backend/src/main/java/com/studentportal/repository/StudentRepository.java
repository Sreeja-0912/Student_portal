package com.studentportal.repository;

import com.studentportal.entity.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    
    Optional<Student> findByRollNumber(String rollNumber);
    Optional<Student> findByEmail(String email);
    boolean existsByRollNumber(String rollNumber);
    boolean existsByEmail(String email);
    
    List<Student> findByDepartment(String department);
    List<Student> findBySemester(Integer semester);
    
    @Query("SELECT s FROM Student s WHERE s.deleted = false AND " +
           "(LOWER(s.firstName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(s.lastName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(s.rollNumber) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Student> searchStudents(@Param("keyword") String keyword, Pageable pageable);
    
    @Query("SELECT s FROM Student s WHERE s.deleted = false")
    Page<Student> findAllActive(Pageable pageable);
    
    @Query("SELECT s FROM Student s WHERE s.department = :department AND s.deleted = false")
    Page<Student> findByDepartment(@Param("department") String department, Pageable pageable);
}
