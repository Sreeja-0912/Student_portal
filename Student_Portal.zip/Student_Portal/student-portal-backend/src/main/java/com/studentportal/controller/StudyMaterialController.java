package com.studentportal.controller;

import com.studentportal.dto.PageResponse;
import com.studentportal.dto.StudyMaterialDto;
import com.studentportal.service.StudyMaterialService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/study-materials")
@RequiredArgsConstructor
@Tag(name = "Study Material Management", description = "Study material management APIs")
public class StudyMaterialController {

    private final StudyMaterialService studyMaterialService;

    @GetMapping
    @Operation(summary = "Get all study materials", description = "Retrieve all study materials with pagination")
    public ResponseEntity<PageResponse<StudyMaterialDto>> getAllStudyMaterials(
            @Parameter(description = "Page number (0-based)") @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Page size") @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(studyMaterialService.getAllStudyMaterials(page, size));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get study material by ID", description = "Retrieve a specific study material by ID")
    public ResponseEntity<StudyMaterialDto> getStudyMaterialById(@PathVariable Long id) {
        return ResponseEntity.ok(studyMaterialService.getStudyMaterialById(id));
    }

    @GetMapping("/course/{courseId}")
    @Operation(summary = "Get study materials by course", description = "Retrieve study materials for a specific course")
    public ResponseEntity<List<StudyMaterialDto>> getStudyMaterialsByCourseId(@PathVariable Long courseId) {
        return ResponseEntity.ok(studyMaterialService.getStudyMaterialsByCourseId(courseId));
    }

    @PostMapping
    @Operation(summary = "Create study material", description = "Create a new study material")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<StudyMaterialDto> createStudyMaterial(@Valid @RequestBody StudyMaterialDto studyMaterialDto) {
        return ResponseEntity.ok(studyMaterialService.createStudyMaterial(studyMaterialDto));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update study material", description = "Update an existing study material")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<StudyMaterialDto> updateStudyMaterial(@PathVariable Long id, @Valid @RequestBody StudyMaterialDto studyMaterialDto) {
        return ResponseEntity.ok(studyMaterialService.updateStudyMaterial(id, studyMaterialDto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete study material", description = "Delete a study material")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteStudyMaterial(@PathVariable Long id) {
        studyMaterialService.deleteStudyMaterial(id);
        return ResponseEntity.noContent().build();
    }
}
