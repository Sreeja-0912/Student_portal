package com.studentportal.repository;

import com.studentportal.entity.StudyMaterial;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudyMaterialRepository extends JpaRepository<StudyMaterial, Long> {
    
    List<StudyMaterial> findByCourseId(Long courseId);
    
    @Query("SELECT sm FROM StudyMaterial sm WHERE sm.course.id = :courseId AND sm.deleted = false")
    List<StudyMaterial> findActiveByCourseId(@Param("courseId") Long courseId);
    
    @Query("SELECT sm FROM StudyMaterial sm WHERE sm.deleted = false")
    Page<StudyMaterial> findAllActive(Pageable pageable);
}
