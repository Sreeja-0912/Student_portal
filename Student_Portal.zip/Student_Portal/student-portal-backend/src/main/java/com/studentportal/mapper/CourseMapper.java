package com.studentportal.mapper;

import com.studentportal.dto.CourseDto;
import com.studentportal.entity.Course;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface CourseMapper {

    CourseDto toDto(Course course);
    Course toEntity(CourseDto courseDto);
    void updateEntityFromDto(CourseDto courseDto, @MappingTarget Course course);
}
