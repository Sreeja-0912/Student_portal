package com.studentportal.service;

import com.studentportal.dto.DashboardSummaryDto;
import com.studentportal.dto.StudentRankingDto;

import java.util.List;
import java.util.Map;

public interface DashboardService {
    DashboardSummaryDto getDashboardSummary();
    List<StudentRankingDto> getTopStudents(Integer limit);
    List<StudentRankingDto> getLowAttendanceStudents(Double threshold);
    List<StudentRankingDto> getAtRiskStudents();
    Map<String, Object> getDepartmentPerformance();
    Map<String, Object> getPassFailStatistics();
    Map<String, Object> getAttendanceStatistics();
    Map<String, Object> getMonthlyEnrollmentReport();
}
