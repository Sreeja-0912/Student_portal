package com.studentportal.service;

import com.studentportal.dto.CourseDto;
import com.studentportal.dto.PageResponse;

import java.util.List;

public interface CourseService {
    PageResponse<CourseDto> getAllCourses(int page, int size, String sortBy, String sortDir, String keyword);
    CourseDto getCourseById(Long id);
    CourseDto getCourseByCode(String courseCode);
    CourseDto createCourse(CourseDto courseDto);
    CourseDto updateCourse(Long id, CourseDto courseDto);
    void deleteCourse(Long id);
    List<CourseDto> getCoursesByFaculty(String facultyName);
}
