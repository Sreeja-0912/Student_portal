package com.studentportal.repository;

import com.studentportal.entity.Marks;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MarksRepository extends JpaRepository<Marks, Long> {
    
    Optional<Marks> findByStudentIdAndCourseId(Long studentId, Long courseId);
    
    List<Marks> findByStudentId(Long studentId);
    List<Marks> findByCourseId(Long courseId);
    
    @Query("SELECT m FROM Marks m WHERE m.student.id = :studentId AND m.deleted = false")
    List<Marks> findByStudentIdActive(@Param("studentId") Long studentId);
    
    @Query("SELECT m FROM Marks m WHERE m.course.id = :courseId AND m.deleted = false")
    List<Marks> findByCourseIdActive(@Param("courseId") Long courseId);
    
    @Query("SELECT m FROM Marks m WHERE m.deleted = false")
    Page<Marks> findAllActive(Pageable pageable);
    
    @Query("SELECT m FROM Marks m WHERE m.deleted = false ORDER BY m.score DESC")
    List<Marks> findAllOrderByScoreDesc();
}
