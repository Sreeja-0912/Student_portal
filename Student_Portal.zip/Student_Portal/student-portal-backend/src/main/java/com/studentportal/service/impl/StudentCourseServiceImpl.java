package com.studentportal.service.impl;

import com.studentportal.dto.StudentCourseDto;
import com.studentportal.entity.Course;
import com.studentportal.entity.Student;
import com.studentportal.entity.StudentCourse;
import com.studentportal.exception.DuplicateResourceException;
import com.studentportal.exception.ResourceNotFoundException;
import com.studentportal.mapper.StudentCourseMapper;
import com.studentportal.repository.CourseRepository;
import com.studentportal.repository.StudentCourseRepository;
import com.studentportal.repository.StudentRepository;
import com.studentportal.service.StudentCourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class StudentCourseServiceImpl implements StudentCourseService {

    private final StudentCourseRepository studentCourseRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    private final StudentCourseMapper studentCourseMapper;

    @Override
    public List<StudentCourseDto> getAllStudentCourses() {
        return studentCourseRepository.findAll().stream()
                .map(studentCourseMapper::toDto)
                .toList();
    }

    @Override
    public List<StudentCourseDto> getStudentCoursesByStudentId(Long studentId) {
        return studentCourseRepository.findActiveByStudentId(studentId).stream()
                .map(studentCourseMapper::toDto)
                .toList();
    }

    @Override
    public List<StudentCourseDto> getStudentCoursesByCourseId(Long courseId) {
        return studentCourseRepository.findActiveByCourseId(courseId).stream()
                .map(studentCourseMapper::toDto)
                .toList();
    }

    @Override
    public StudentCourseDto enrollStudent(StudentCourseDto studentCourseDto) {
        if (studentCourseRepository.findByStudentIdAndCourseId(studentCourseDto.getStudentId(), studentCourseDto.getCourseId()).isPresent()) {
            throw new DuplicateResourceException("Student is already enrolled in this course");
        }

        Student student = studentRepository.findById(studentCourseDto.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + studentCourseDto.getStudentId()));
        
        Course course = courseRepository.findById(studentCourseDto.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + studentCourseDto.getCourseId()));

        StudentCourse studentCourse = studentCourseMapper.toEntity(studentCourseDto);
        studentCourse.setStudent(student);
        studentCourse.setCourse(course);
        studentCourse.setEnrollmentDate(LocalDate.now());
        
        studentCourse = studentCourseRepository.save(studentCourse);
        return studentCourseMapper.toDto(studentCourse);
    }

    @Override
    public void unenrollStudent(Long studentId, Long courseId) {
        StudentCourse studentCourse = studentCourseRepository.findByStudentIdAndCourseId(studentId, courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found"));
        studentCourse.setDeleted(true);
        studentCourseRepository.save(studentCourse);
    }

    @Override
    public StudentCourseDto updateEnrollment(Long id, StudentCourseDto studentCourseDto) {
        StudentCourse existingEnrollment = studentCourseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found with id: " + id));

        if (studentCourseDto.getEnrollmentDate() != null) {
            existingEnrollment.setEnrollmentDate(studentCourseDto.getEnrollmentDate());
        }

        existingEnrollment = studentCourseRepository.save(existingEnrollment);
        return studentCourseMapper.toDto(existingEnrollment);
    }

    @Override
    public void deleteEnrollment(Long id) {
        StudentCourse studentCourse = studentCourseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found with id: " + id));
        studentCourse.setDeleted(true);
        studentCourseRepository.save(studentCourse);
    }
}
