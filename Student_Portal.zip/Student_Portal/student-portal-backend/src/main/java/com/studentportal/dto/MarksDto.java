package com.studentportal.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MarksDto {
    
    private Long id;
    private Long studentId;
    private String studentName;
    private String rollNumber;
    private Long courseId;
    private String courseCode;
    private String courseName;
    
    @NotNull(message = "Score is required")
    private Double score;
    
    private Double maxScore;
    private String grade;
    private LocalDate examDate;
}
