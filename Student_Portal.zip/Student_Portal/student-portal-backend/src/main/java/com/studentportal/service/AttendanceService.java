package com.studentportal.service;

import com.studentportal.dto.AttendanceDto;
import com.studentportal.dto.PageResponse;

import java.util.List;

public interface AttendanceService {
    PageResponse<AttendanceDto> getAllAttendance(int page, int size);
    AttendanceDto getAttendanceById(Long id);
    AttendanceDto getAttendanceByStudentAndCourse(Long studentId, Long courseId);
    List<AttendanceDto> getAttendanceByStudentId(Long studentId);
    List<AttendanceDto> getAttendanceByCourseId(Long courseId);
    AttendanceDto createAttendance(AttendanceDto attendanceDto);
    AttendanceDto updateAttendance(Long id, AttendanceDto attendanceDto);
    void deleteAttendance(Long id);
    List<AttendanceDto> getDefaulters();
}
