package com.studentportal.service.impl;

import com.studentportal.dto.AttendanceDto;
import com.studentportal.dto.PageResponse;
import com.studentportal.entity.Attendance;
import com.studentportal.entity.Course;
import com.studentportal.entity.Student;
import com.studentportal.exception.DuplicateResourceException;
import com.studentportal.exception.ResourceNotFoundException;
import com.studentportal.mapper.AttendanceMapper;
import com.studentportal.repository.AttendanceRepository;
import com.studentportal.repository.CourseRepository;
import com.studentportal.repository.StudentRepository;
import com.studentportal.service.AttendanceService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class AttendanceServiceImpl implements AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    private final AttendanceMapper attendanceMapper;

    @Override
    public PageResponse<AttendanceDto> getAllAttendance(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("student.firstName").ascending());
        Page<Attendance> attendancePage = attendanceRepository.findAllActive(pageable);

        return new PageResponse<>(
                attendancePage.getContent().stream().map(attendanceMapper::toDto).toList(),
                attendancePage.getNumber(),
                attendancePage.getSize(),
                attendancePage.getTotalElements(),
                attendancePage.getTotalPages(),
                attendancePage.isFirst(),
                attendancePage.isLast()
        );
    }

    @Override
    public AttendanceDto getAttendanceById(Long id) {
        Attendance attendance = attendanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Attendance not found with id: " + id));
        return attendanceMapper.toDto(attendance);
    }

    @Override
    public AttendanceDto getAttendanceByStudentAndCourse(Long studentId, Long courseId) {
        Attendance attendance = attendanceRepository.findByStudentIdAndCourseId(studentId, courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Attendance not found for student and course"));
        return attendanceMapper.toDto(attendance);
    }

    @Override
    public List<AttendanceDto> getAttendanceByStudentId(Long studentId) {
        return attendanceRepository.findByStudentIdActive(studentId).stream()
                .map(attendanceMapper::toDto)
                .toList();
    }

    @Override
    public List<AttendanceDto> getAttendanceByCourseId(Long courseId) {
        return attendanceRepository.findByCourseIdActive(courseId).stream()
                .map(attendanceMapper::toDto)
                .toList();
    }

    @Override
    public AttendanceDto createAttendance(AttendanceDto attendanceDto) {
        if (attendanceRepository.findByStudentIdAndCourseId(attendanceDto.getStudentId(), attendanceDto.getCourseId()).isPresent()) {
            throw new DuplicateResourceException("Attendance already exists for this student and course");
        }

        Student student = studentRepository.findById(attendanceDto.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + attendanceDto.getStudentId()));
        
        Course course = courseRepository.findById(attendanceDto.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + attendanceDto.getCourseId()));

        Attendance attendance = attendanceMapper.toEntity(attendanceDto);
        attendance.setStudent(student);
        attendance.setCourse(course);
        
        attendance = attendanceRepository.save(attendance);
        return attendanceMapper.toDto(attendance);
    }

    @Override
    public AttendanceDto updateAttendance(Long id, AttendanceDto attendanceDto) {
        Attendance existingAttendance = attendanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Attendance not found with id: " + id));

        attendanceMapper.updateEntityFromDto(attendanceDto, existingAttendance);
        existingAttendance = attendanceRepository.save(existingAttendance);
        return attendanceMapper.toDto(existingAttendance);
    }

    @Override
    public void deleteAttendance(Long id) {
        Attendance attendance = attendanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Attendance not found with id: " + id));
        attendance.setDeleted(true);
        attendanceRepository.save(attendance);
    }

    @Override
    public List<AttendanceDto> getDefaulters() {
        return attendanceRepository.findDefaulters().stream()
                .map(attendanceMapper::toDto)
                .toList();
    }
}
