package com.studentportal.service.impl;

import com.studentportal.dto.AttendanceDto;
import com.studentportal.dto.DashboardSummaryDto;
import com.studentportal.dto.MarksDto;
import com.studentportal.dto.StudentRankingDto;
import com.studentportal.entity.Attendance;
import com.studentportal.entity.Marks;
import com.studentportal.entity.Student;
import com.studentportal.mapper.AttendanceMapper;
import com.studentportal.mapper.MarksMapper;
import com.studentportal.repository.AttendanceRepository;
import com.studentportal.repository.CourseRepository;
import com.studentportal.repository.MarksRepository;
import com.studentportal.repository.StudentRepository;
import com.studentportal.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class DashboardServiceImpl implements DashboardService {

    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    private final MarksRepository marksRepository;
    private final AttendanceRepository attendanceRepository;
    private final MarksMapper marksMapper;
    private final AttendanceMapper attendanceMapper;

    @Override
    public DashboardSummaryDto getDashboardSummary() {
        long totalStudents = studentRepository.count();
        long totalCourses = courseRepository.count();
        
        List<Attendance> allAttendance = attendanceRepository.findAll();
        double averageAttendance = allAttendance.stream()
                .mapToDouble(Attendance::getAttendancePercentage)
                .average()
                .orElse(0.0);
        
        List<Marks> allMarks = marksRepository.findAll();
        long passedStudents = allMarks.stream()
                .filter(m -> m.getScore() >= 40)
                .map(Marks::getStudent)
                .distinct()
                .count();
        double passPercentage = totalStudents > 0 ? (passedStudents * 100.0 / totalStudents) : 0.0;

        return new DashboardSummaryDto(
                totalStudents,
                totalCourses,
                averageAttendance,
                passPercentage,
                0L,
                0L
        );
    }

    @Override
    public List<StudentRankingDto> getTopStudents(Integer limit) {
        List<StudentRankingDto> rankings = getStudentRankings();
        if (limit != null && limit > 0) {
            return rankings.stream().limit(limit).toList();
        }
        return rankings;
    }

    @Override
    public List<StudentRankingDto> getLowAttendanceStudents(Double threshold) {
        double thresholdValue = threshold != null ? threshold : 75.0;
        List<Attendance> lowAttendance = attendanceRepository.findDefaulters();
        
        return lowAttendance.stream()
                .map(att -> {
                    StudentRankingDto dto = new StudentRankingDto();
                    dto.setId(att.getStudent().getId());
                    dto.setRollNumber(att.getStudent().getRollNumber());
                    dto.setFirstName(att.getStudent().getFirstName());
                    dto.setLastName(att.getStudent().getLastName());
                    dto.setDepartment(att.getStudent().getDepartment());
                    dto.setAverageScore(0.0);
                    return dto;
                })
                .distinct()
                .toList();
    }

    @Override
    public List<StudentRankingDto> getAtRiskStudents() {
        List<Marks> failingMarks = marksRepository.findAll().stream()
                .filter(m -> m.getScore() < 40)
                .toList();
        
        return failingMarks.stream()
                .map(m -> {
                    StudentRankingDto dto = new StudentRankingDto();
                    dto.setId(m.getStudent().getId());
                    dto.setRollNumber(m.getStudent().getRollNumber());
                    dto.setFirstName(m.getStudent().getFirstName());
                    dto.setLastName(m.getStudent().getLastName());
                    dto.setDepartment(m.getStudent().getDepartment());
                    dto.setAverageScore(m.getScore());
                    return dto;
                })
                .distinct()
                .toList();
    }

    @Override
    public Map<String, Object> getDepartmentPerformance() {
        List<Student> students = studentRepository.findAll();
        Map<String, List<Student>> studentsByDept = students.stream()
                .collect(Collectors.groupingBy(Student::getDepartment));
        
        Map<String, Object> performance = new HashMap<>();
        for (Map.Entry<String, List<Student>> entry : studentsByDept.entrySet()) {
            String dept = entry.getKey();
            List<Student> deptStudents = entry.getValue();
            
            List<Long> studentIds = deptStudents.stream().map(Student::getId).toList();
            List<Marks> deptMarks = marksRepository.findAll().stream()
                    .filter(m -> studentIds.contains(m.getStudent().getId()))
                    .toList();
            
            double avgScore = deptMarks.stream().mapToDouble(Marks::getScore).average().orElse(0.0);
            
            Map<String, Object> deptData = new HashMap<>();
            deptData.put("studentCount", deptStudents.size());
            deptData.put("averageScore", avgScore);
            performance.put(dept, deptData);
        }
        
        return performance;
    }

    @Override
    public Map<String, Object> getPassFailStatistics() {
        List<Marks> allMarks = marksRepository.findAll();
        long passed = allMarks.stream().filter(m -> m.getScore() >= 40).count();
        long failed = allMarks.stream().filter(m -> m.getScore() < 40).count();
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("passed", passed);
        stats.put("failed", failed);
        stats.put("passRate", allMarks.size() > 0 ? (passed * 100.0 / allMarks.size()) : 0.0);
        
        return stats;
    }

    @Override
    public Map<String, Object> getAttendanceStatistics() {
        List<Attendance> allAttendance = attendanceRepository.findAll();
        
        long above75 = allAttendance.stream().filter(a -> a.getAttendancePercentage() >= 75).count();
        long below75 = allAttendance.stream().filter(a -> a.getAttendancePercentage() < 75).count();
        
        double avgAttendance = allAttendance.stream()
                .mapToDouble(Attendance::getAttendancePercentage)
                .average()
                .orElse(0.0);
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("above75", above75);
        stats.put("below75", below75);
        stats.put("averageAttendance", avgAttendance);
        
        return stats;
    }

    @Override
    public Map<String, Object> getMonthlyEnrollmentReport() {
        List<Student> students = studentRepository.findAll();
        Map<String, Long> monthlyEnrollments = new HashMap<>();
        
        for (int i = 1; i <= 12; i++) {
            YearMonth yearMonth = YearMonth.of(LocalDate.now().getYear(), i);
            long count = students.stream()
                    .filter(s -> s.getCreatedDate() != null)
                    .filter(s -> {
                        YearMonth studentMonth = YearMonth.from(s.getCreatedDate());
                        return studentMonth.equals(yearMonth);
                    })
                    .count();
            monthlyEnrollments.put(yearMonth.getMonth().toString(), count);
        }
        
        Map<String, Object> report = new HashMap<>();
        report.put("monthlyEnrollments", monthlyEnrollments);
        report.put("totalEnrollments", students.size());
        
        return report;
    }
}
