package com.studentportal.controller;

import com.studentportal.dto.AnnouncementDto;
import com.studentportal.dto.PageResponse;
import com.studentportal.service.AnnouncementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/announcements")
@RequiredArgsConstructor
@Tag(name = "Announcement Management", description = "Announcement management APIs")
public class AnnouncementController {

    private final AnnouncementService announcementService;

    @GetMapping
    @Operation(summary = "Get all announcements", description = "Retrieve all announcements with pagination")
    public ResponseEntity<PageResponse<AnnouncementDto>> getAllAnnouncements(
            @Parameter(description = "Page number (0-based)") @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Page size") @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(announcementService.getAllAnnouncements(page, size));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get announcement by ID", description = "Retrieve a specific announcement by ID")
    public ResponseEntity<AnnouncementDto> getAnnouncementById(@PathVariable Long id) {
        return ResponseEntity.ok(announcementService.getAnnouncementById(id));
    }

    @GetMapping("/audience/{audience}")
    @Operation(summary = "Get announcements by target audience", description = "Retrieve announcements for a specific target audience")
    public ResponseEntity<List<AnnouncementDto>> getAnnouncementsByTargetAudience(@PathVariable String audience) {
        return ResponseEntity.ok(announcementService.getAnnouncementsByTargetAudience(audience));
    }

    @PostMapping
    @Operation(summary = "Create announcement", description = "Create a new announcement")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<AnnouncementDto> createAnnouncement(@Valid @RequestBody AnnouncementDto announcementDto) {
        return ResponseEntity.ok(announcementService.createAnnouncement(announcementDto));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update announcement", description = "Update an existing announcement")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<AnnouncementDto> updateAnnouncement(@PathVariable Long id, @Valid @RequestBody AnnouncementDto announcementDto) {
        return ResponseEntity.ok(announcementService.updateAnnouncement(id, announcementDto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete announcement", description = "Delete an announcement")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteAnnouncement(@PathVariable Long id) {
        announcementService.deleteAnnouncement(id);
        return ResponseEntity.noContent().build();
    }
}
