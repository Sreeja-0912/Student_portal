package com.studentportal.mapper;

import com.studentportal.dto.StudentCourseDto;
import com.studentportal.entity.StudentCourse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface StudentCourseMapper {

    @Mapping(source = "student.id", target = "studentId")
    @Mapping(source = "student.firstName", target = "studentName")
    @Mapping(source = "course.id", target = "courseId")
    @Mapping(source = "course.courseCode", target = "courseCode")
    @Mapping(source = "course.courseName", target = "courseName")
    StudentCourseDto toDto(StudentCourse studentCourse);

    StudentCourse toEntity(StudentCourseDto studentCourseDto);
}
