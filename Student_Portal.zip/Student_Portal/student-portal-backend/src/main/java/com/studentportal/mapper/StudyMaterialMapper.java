package com.studentportal.mapper;

import com.studentportal.dto.StudyMaterialDto;
import com.studentportal.entity.StudyMaterial;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface StudyMaterialMapper {

    @Mapping(source = "course.id", target = "courseId")
    @Mapping(source = "course.courseCode", target = "courseCode")
    @Mapping(source = "course.courseName", target = "courseName")
    StudyMaterialDto toDto(StudyMaterial studyMaterial);

    StudyMaterial toEntity(StudyMaterialDto studyMaterialDto);
    void updateEntityFromDto(StudyMaterialDto studyMaterialDto, @MappingTarget StudyMaterial studyMaterial);
}
