package com.studentportal.repository;

import com.studentportal.entity.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    
    List<AuditLog> findByUsername(String username);
    List<AuditLog> findByAction(String action);
    
    @Query("SELECT al FROM AuditLog al WHERE al.createdDate BETWEEN :startDate AND :endDate")
    List<AuditLog> findByDateRange(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT al FROM AuditLog al WHERE al.username = :username AND al.createdDate BETWEEN :startDate AND :endDate")
    List<AuditLog> findByUsernameAndDateRange(@Param("username") String username, 
                                               @Param("startDate") LocalDateTime startDate, 
                                               @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT al FROM AuditLog al ORDER BY al.createdDate DESC")
    Page<AuditLog> findAllOrderByCreatedDateDesc(Pageable pageable);
}
