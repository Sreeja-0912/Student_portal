package com.studentportal.service.impl;

import com.studentportal.dto.CourseDto;
import com.studentportal.dto.PageResponse;
import com.studentportal.entity.Course;
import com.studentportal.exception.DuplicateResourceException;
import com.studentportal.exception.ResourceNotFoundException;
import com.studentportal.mapper.CourseMapper;
import com.studentportal.repository.CourseRepository;
import com.studentportal.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;
    private final CourseMapper courseMapper;

    @Override
    public PageResponse<CourseDto> getAllCourses(int page, int size, String sortBy, String sortDir, String keyword) {
        Sort sort = sortDir.equalsIgnoreCase("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<Course> coursePage;
        if (keyword != null && !keyword.isEmpty()) {
            coursePage = courseRepository.searchCourses(keyword, pageable);
        } else {
            coursePage = courseRepository.findAllActive(pageable);
        }

        return new PageResponse<>(
                coursePage.getContent().stream().map(courseMapper::toDto).toList(),
                coursePage.getNumber(),
                coursePage.getSize(),
                coursePage.getTotalElements(),
                coursePage.getTotalPages(),
                coursePage.isFirst(),
                coursePage.isLast()
        );
    }

    @Override
    public CourseDto getCourseById(Long id) {
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + id));
        return courseMapper.toDto(course);
    }

    @Override
    public CourseDto getCourseByCode(String courseCode) {
        Course course = courseRepository.findByCourseCode(courseCode)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with code: " + courseCode));
        return courseMapper.toDto(course);
    }

    @Override
    public CourseDto createCourse(CourseDto courseDto) {
        if (courseRepository.existsByCourseCode(courseDto.getCourseCode())) {
            throw new DuplicateResourceException("Course code already exists: " + courseDto.getCourseCode());
        }

        Course course = courseMapper.toEntity(courseDto);
        course = courseRepository.save(course);
        return courseMapper.toDto(course);
    }

    @Override
    public CourseDto updateCourse(Long id, CourseDto courseDto) {
        Course existingCourse = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + id));

        if (!existingCourse.getCourseCode().equals(courseDto.getCourseCode()) && 
            courseRepository.existsByCourseCode(courseDto.getCourseCode())) {
            throw new DuplicateResourceException("Course code already exists: " + courseDto.getCourseCode());
        }

        courseMapper.updateEntityFromDto(courseDto, existingCourse);
        existingCourse = courseRepository.save(existingCourse);
        return courseMapper.toDto(existingCourse);
    }

    @Override
    public void deleteCourse(Long id) {
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + id));
        course.setDeleted(true);
        courseRepository.save(course);
    }

    @Override
    public List<CourseDto> getCoursesByFaculty(String facultyName) {
        return courseRepository.findByFacultyName(facultyName).stream()
                .map(courseMapper::toDto)
                .toList();
    }
}
