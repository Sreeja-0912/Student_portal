package com.studentportal.controller;

import com.studentportal.dto.AttendanceDto;
import com.studentportal.dto.PageResponse;
import com.studentportal.service.AttendanceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/attendance")
@RequiredArgsConstructor
@Tag(name = "Attendance Management", description = "Attendance management APIs")
public class AttendanceController {

    private final AttendanceService attendanceService;

    @GetMapping
    @Operation(summary = "Get all attendance records", description = "Retrieve all attendance records with pagination")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<PageResponse<AttendanceDto>> getAllAttendance(
            @Parameter(description = "Page number (0-based)") @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Page size") @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(attendanceService.getAllAttendance(page, size));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get attendance by ID", description = "Retrieve a specific attendance record by ID")
    public ResponseEntity<AttendanceDto> getAttendanceById(@PathVariable Long id) {
        return ResponseEntity.ok(attendanceService.getAttendanceById(id));
    }

    @GetMapping("/student/{studentId}")
    @Operation(summary = "Get attendance by student", description = "Retrieve attendance records for a specific student")
    public ResponseEntity<List<AttendanceDto>> getAttendanceByStudentId(@PathVariable Long studentId) {
        return ResponseEntity.ok(attendanceService.getAttendanceByStudentId(studentId));
    }

    @GetMapping("/course/{courseId}")
    @Operation(summary = "Get attendance by course", description = "Retrieve attendance records for a specific course")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<List<AttendanceDto>> getAttendanceByCourseId(@PathVariable Long courseId) {
        return ResponseEntity.ok(attendanceService.getAttendanceByCourseId(courseId));
    }

    @GetMapping("/student/{studentId}/course/{courseId}")
    @Operation(summary = "Get attendance by student and course", description = "Retrieve attendance record for a specific student and course")
    public ResponseEntity<AttendanceDto> getAttendanceByStudentAndCourse(
            @PathVariable Long studentId, @PathVariable Long courseId) {
        return ResponseEntity.ok(attendanceService.getAttendanceByStudentAndCourse(studentId, courseId));
    }

    @GetMapping("/defaulters")
    @Operation(summary = "Get attendance defaulters", description = "Retrieve students with attendance below 75%")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<List<AttendanceDto>> getDefaulters() {
        return ResponseEntity.ok(attendanceService.getDefaulters());
    }

    @PostMapping
    @Operation(summary = "Create attendance record", description = "Create a new attendance record")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<AttendanceDto> createAttendance(@Valid @RequestBody AttendanceDto attendanceDto) {
        return ResponseEntity.ok(attendanceService.createAttendance(attendanceDto));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update attendance record", description = "Update an existing attendance record")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<AttendanceDto> updateAttendance(@PathVariable Long id, @Valid @RequestBody AttendanceDto attendanceDto) {
        return ResponseEntity.ok(attendanceService.updateAttendance(id, attendanceDto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete attendance record", description = "Delete an attendance record")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteAttendance(@PathVariable Long id) {
        attendanceService.deleteAttendance(id);
        return ResponseEntity.noContent().build();
    }
}
