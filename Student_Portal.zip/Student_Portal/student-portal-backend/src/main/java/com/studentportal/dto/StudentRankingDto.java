package com.studentportal.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentRankingDto {
    
    private Long id;
    private String rollNumber;
    private String firstName;
    private String lastName;
    private String department;
    private Double averageScore;
    private Integer rank;
    private Long totalCourses;
}
