package com.studentportal.controller;

import com.studentportal.dto.MarksDto;
import com.studentportal.dto.PageResponse;
import com.studentportal.dto.StudentRankingDto;
import com.studentportal.service.MarksService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/marks")
@RequiredArgsConstructor
@Tag(name = "Marks Management", description = "Marks management APIs")
public class MarksController {

    private final MarksService marksService;

    @GetMapping
    @Operation(summary = "Get all marks", description = "Retrieve all marks with pagination")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<PageResponse<MarksDto>> getAllMarks(
            @Parameter(description = "Page number (0-based)") @RequestParam(defaultValue = "0") int page,
            @Parameter(description = "Page size") @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(marksService.getAllMarks(page, size));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get marks by ID", description = "Retrieve a specific marks record by ID")
    public ResponseEntity<MarksDto> getMarksById(@PathVariable Long id) {
        return ResponseEntity.ok(marksService.getMarksById(id));
    }

    @GetMapping("/student/{studentId}")
    @Operation(summary = "Get marks by student", description = "Retrieve marks for a specific student")
    public ResponseEntity<List<MarksDto>> getMarksByStudentId(@PathVariable Long studentId) {
        return ResponseEntity.ok(marksService.getMarksByStudentId(studentId));
    }

    @GetMapping("/course/{courseId}")
    @Operation(summary = "Get marks by course", description = "Retrieve marks for a specific course")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<List<MarksDto>> getMarksByCourseId(@PathVariable Long courseId) {
        return ResponseEntity.ok(marksService.getMarksByCourseId(courseId));
    }

    @GetMapping("/student/{studentId}/course/{courseId}")
    @Operation(summary = "Get marks by student and course", description = "Retrieve marks for a specific student and course")
    public ResponseEntity<MarksDto> getMarksByStudentAndCourse(
            @PathVariable Long studentId, @PathVariable Long courseId) {
        return ResponseEntity.ok(marksService.getMarksByStudentAndCourse(studentId, courseId));
    }

    @GetMapping("/rankings")
    @Operation(summary = "Get student rankings", description = "Retrieve student rankings based on average scores")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<List<StudentRankingDto>> getStudentRankings() {
        return ResponseEntity.ok(marksService.getStudentRankings());
    }

    @PostMapping
    @Operation(summary = "Create marks record", description = "Create a new marks record")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<MarksDto> createMarks(@Valid @RequestBody MarksDto marksDto) {
        return ResponseEntity.ok(marksService.createMarks(marksDto));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update marks record", description = "Update an existing marks record")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<MarksDto> updateMarks(@PathVariable Long id, @Valid @RequestBody MarksDto marksDto) {
        return ResponseEntity.ok(marksService.updateMarks(id, marksDto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete marks record", description = "Delete a marks record")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteMarks(@PathVariable Long id) {
        marksService.deleteMarks(id);
        return ResponseEntity.noContent().build();
    }
}
