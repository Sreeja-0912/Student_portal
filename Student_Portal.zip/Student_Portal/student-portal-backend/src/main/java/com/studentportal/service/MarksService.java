package com.studentportal.service;

import com.studentportal.dto.MarksDto;
import com.studentportal.dto.PageResponse;
import com.studentportal.dto.StudentRankingDto;

import java.util.List;

public interface MarksService {
    PageResponse<MarksDto> getAllMarks(int page, int size);
    MarksDto getMarksById(Long id);
    MarksDto getMarksByStudentAndCourse(Long studentId, Long courseId);
    List<MarksDto> getMarksByStudentId(Long studentId);
    List<MarksDto> getMarksByCourseId(Long courseId);
    MarksDto createMarks(MarksDto marksDto);
    MarksDto updateMarks(Long id, MarksDto marksDto);
    void deleteMarks(Long id);
    List<StudentRankingDto> getStudentRankings();
}
