package com.studentportal.controller;

import com.studentportal.dto.DashboardSummaryDto;
import com.studentportal.dto.StudentRankingDto;
import com.studentportal.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
@Tag(name = "Dashboard", description = "Dashboard and reporting APIs")
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/summary")
    @Operation(summary = "Get dashboard summary", description = "Retrieve dashboard summary statistics")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<DashboardSummaryDto> getDashboardSummary() {
        return ResponseEntity.ok(dashboardService.getDashboardSummary());
    }

    @GetMapping("/top-students")
    @Operation(summary = "Get top students", description = "Retrieve top performing students")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<List<StudentRankingDto>> getTopStudents(
            @Parameter(description = "Limit number of results") @RequestParam(defaultValue = "10") Integer limit) {
        return ResponseEntity.ok(dashboardService.getTopStudents(limit));
    }

    @GetMapping("/low-attendance")
    @Operation(summary = "Get low attendance students", description = "Retrieve students with low attendance")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<List<StudentRankingDto>> getLowAttendanceStudents(
            @Parameter(description = "Attendance threshold percentage") @RequestParam(defaultValue = "75") Double threshold) {
        return ResponseEntity.ok(dashboardService.getLowAttendanceStudents(threshold));
    }

    @GetMapping("/at-risk-students")
    @Operation(summary = "Get at-risk students", description = "Retrieve students at risk of failing")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<List<StudentRankingDto>> getAtRiskStudents() {
        return ResponseEntity.ok(dashboardService.getAtRiskStudents());
    }

    @GetMapping("/department-performance")
    @Operation(summary = "Get department performance", description = "Retrieve performance statistics by department")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<Map<String, Object>> getDepartmentPerformance() {
        return ResponseEntity.ok(dashboardService.getDepartmentPerformance());
    }

    @GetMapping("/pass-fail-stats")
    @Operation(summary = "Get pass/fail statistics", description = "Retrieve pass vs fail statistics")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<Map<String, Object>> getPassFailStatistics() {
        return ResponseEntity.ok(dashboardService.getPassFailStatistics());
    }

    @GetMapping("/attendance-stats")
    @Operation(summary = "Get attendance statistics", description = "Retrieve attendance statistics")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<Map<String, Object>> getAttendanceStatistics() {
        return ResponseEntity.ok(dashboardService.getAttendanceStatistics());
    }

    @GetMapping("/monthly-enrollment")
    @Operation(summary = "Get monthly enrollment report", description = "Retrieve monthly enrollment report")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Map<String, Object>> getMonthlyEnrollmentReport() {
        return ResponseEntity.ok(dashboardService.getMonthlyEnrollmentReport());
    }
}
