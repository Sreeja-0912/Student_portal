package com.studentportal.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceDto {
    
    private Long id;
    private Long studentId;
    private String studentName;
    private String rollNumber;
    private Long courseId;
    private String courseCode;
    private String courseName;
    
    @NotNull(message = "Attendance percentage is required")
    private Double attendancePercentage;
    
    private Integer totalClasses;
    private Integer attendedClasses;
}
