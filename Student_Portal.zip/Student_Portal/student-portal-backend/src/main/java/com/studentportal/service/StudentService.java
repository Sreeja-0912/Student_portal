package com.studentportal.service;

import com.studentportal.dto.PageResponse;
import com.studentportal.dto.StudentDto;

public interface StudentService {
    PageResponse<StudentDto> getAllStudents(int page, int size, String sortBy, String sortDir, String keyword);
    StudentDto getStudentById(Long id);
    StudentDto getStudentByRollNumber(String rollNumber);
    StudentDto createStudent(StudentDto studentDto);
    StudentDto updateStudent(Long id, StudentDto studentDto);
    void deleteStudent(Long id);
    PageResponse<StudentDto> getStudentsByDepartment(String department, int page, int size);
}
