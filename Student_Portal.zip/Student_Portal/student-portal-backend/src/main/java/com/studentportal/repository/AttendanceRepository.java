package com.studentportal.repository;

import com.studentportal.entity.Attendance;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    
    Optional<Attendance> findByStudentIdAndCourseId(Long studentId, Long courseId);
    
    List<Attendance> findByStudentId(Long studentId);
    List<Attendance> findByCourseId(Long courseId);
    
    @Query("SELECT a FROM Attendance a WHERE a.attendancePercentage < 75 AND a.deleted = false")
    List<Attendance> findDefaulters();
    
    @Query("SELECT a FROM Attendance a WHERE a.student.id = :studentId AND a.deleted = false")
    List<Attendance> findByStudentIdActive(@Param("studentId") Long studentId);
    
    @Query("SELECT a FROM Attendance a WHERE a.course.id = :courseId AND a.deleted = false")
    List<Attendance> findByCourseIdActive(@Param("courseId") Long courseId);
    
    @Query("SELECT a FROM Attendance a WHERE a.deleted = false")
    Page<Attendance> findAllActive(Pageable pageable);
}
