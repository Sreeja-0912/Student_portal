package com.studentportal.service.impl;

import com.studentportal.dto.AnnouncementDto;
import com.studentportal.dto.PageResponse;
import com.studentportal.entity.Announcement;
import com.studentportal.exception.ResourceNotFoundException;
import com.studentportal.mapper.AnnouncementMapper;
import com.studentportal.repository.AnnouncementRepository;
import com.studentportal.service.AnnouncementService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class AnnouncementServiceImpl implements AnnouncementService {

    private final AnnouncementRepository announcementRepository;
    private final AnnouncementMapper announcementMapper;

    @Override
    public PageResponse<AnnouncementDto> getAllAnnouncements(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdDate").descending());
        Page<Announcement> announcementPage = announcementRepository.findAllActive(pageable);

        return new PageResponse<>(
                announcementPage.getContent().stream().map(announcementMapper::toDto).toList(),
                announcementPage.getNumber(),
                announcementPage.getSize(),
                announcementPage.getTotalElements(),
                announcementPage.getTotalPages(),
                announcementPage.isFirst(),
                announcementPage.isLast()
        );
    }

    @Override
    public AnnouncementDto getAnnouncementById(Long id) {
        Announcement announcement = announcementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Announcement not found with id: " + id));
        return announcementMapper.toDto(announcement);
    }

    @Override
    public List<AnnouncementDto> getAnnouncementsByTargetAudience(String audience) {
        return announcementRepository.findByTargetAudience(audience).stream()
                .map(announcementMapper::toDto)
                .toList();
    }

    @Override
    public AnnouncementDto createAnnouncement(AnnouncementDto announcementDto) {
        Announcement announcement = announcementMapper.toEntity(announcementDto);
        announcement.setPriority(announcementDto.getPriority() != null ? announcementDto.getPriority() : "NORMAL");
        announcement.setTargetAudience(announcementDto.getTargetAudience() != null ? announcementDto.getTargetAudience() : "ALL");
        announcement = announcementRepository.save(announcement);
        return announcementMapper.toDto(announcement);
    }

    @Override
    public AnnouncementDto updateAnnouncement(Long id, AnnouncementDto announcementDto) {
        Announcement existingAnnouncement = announcementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Announcement not found with id: " + id));

        announcementMapper.updateEntityFromDto(announcementDto, existingAnnouncement);
        existingAnnouncement = announcementRepository.save(existingAnnouncement);
        return announcementMapper.toDto(existingAnnouncement);
    }

    @Override
    public void deleteAnnouncement(Long id) {
        Announcement announcement = announcementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Announcement not found with id: " + id));
        announcement.setDeleted(true);
        announcementRepository.save(announcement);
    }
}
