package com.studentportal.repository;

import com.studentportal.entity.Announcement;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AnnouncementRepository extends JpaRepository<Announcement, Long> {
    
    @Query("SELECT a FROM Announcement a WHERE a.deleted = false ORDER BY a.createdDate DESC")
    List<Announcement> findAllActiveOrderByCreatedDateDesc();
    
    @Query("SELECT a FROM Announcement a WHERE a.deleted = false AND a.targetAudience = :audience ORDER BY a.createdDate DESC")
    List<Announcement> findByTargetAudience(@Param("audience") String audience);
    
    @Query("SELECT a FROM Announcement a WHERE a.deleted = false")
    Page<Announcement> findAllActive(Pageable pageable);
}
