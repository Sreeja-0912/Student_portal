package com.studentportal.service;

import com.studentportal.dto.AnnouncementDto;
import com.studentportal.dto.PageResponse;

import java.util.List;

public interface AnnouncementService {
    PageResponse<AnnouncementDto> getAllAnnouncements(int page, int size);
    AnnouncementDto getAnnouncementById(Long id);
    List<AnnouncementDto> getAnnouncementsByTargetAudience(String audience);
    AnnouncementDto createAnnouncement(AnnouncementDto announcementDto);
    AnnouncementDto updateAnnouncement(Long id, AnnouncementDto announcementDto);
    void deleteAnnouncement(Long id);
}
