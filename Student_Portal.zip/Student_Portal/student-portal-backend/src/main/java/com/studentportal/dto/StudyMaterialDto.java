package com.studentportal.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudyMaterialDto {
    
    private Long id;
    
    @NotNull(message = "Course ID is required")
    private Long courseId;
    private String courseCode;
    private String courseName;
    
    @NotBlank(message = "Title is required")
    @Size(max = 200, message = "Title must not exceed 200 characters")
    private String title;
    
    private String description;
    private String fileUrl;
    private String fileType;
    private LocalDate uploadDate;
}
