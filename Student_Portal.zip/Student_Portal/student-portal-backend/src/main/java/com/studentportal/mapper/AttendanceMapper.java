package com.studentportal.mapper;

import com.studentportal.dto.AttendanceDto;
import com.studentportal.entity.Attendance;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface AttendanceMapper {

    @Mapping(source = "student.id", target = "studentId")
    @Mapping(source = "student.firstName", target = "studentName")
    @Mapping(source = "student.rollNumber", target = "rollNumber")
    @Mapping(source = "course.id", target = "courseId")
    @Mapping(source = "course.courseCode", target = "courseCode")
    @Mapping(source = "course.courseName", target = "courseName")
    AttendanceDto toDto(Attendance attendance);

    Attendance toEntity(AttendanceDto attendanceDto);
    void updateEntityFromDto(AttendanceDto attendanceDto, @MappingTarget Attendance attendance);
}
