package com.studentportal.repository;

import com.studentportal.entity.Course;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {
    
    Optional<Course> findByCourseCode(String courseCode);
    boolean existsByCourseCode(String courseCode);
    
    List<Course> findByFacultyName(String facultyName);
    
    @Query("SELECT c FROM Course c WHERE c.deleted = false AND " +
           "(LOWER(c.courseCode) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.courseName) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<Course> searchCourses(@Param("keyword") String keyword, Pageable pageable);
    
    @Query("SELECT c FROM Course c WHERE c.deleted = false")
    Page<Course> findAllActive(Pageable pageable);
}
