package com.studentportal.service.impl;

import com.studentportal.dto.MarksDto;
import com.studentportal.dto.PageResponse;
import com.studentportal.dto.StudentRankingDto;
import com.studentportal.entity.Course;
import com.studentportal.entity.Marks;
import com.studentportal.entity.Student;
import com.studentportal.exception.DuplicateResourceException;
import com.studentportal.exception.ResourceNotFoundException;
import com.studentportal.mapper.MarksMapper;
import com.studentportal.repository.CourseRepository;
import com.studentportal.repository.MarksRepository;
import com.studentportal.repository.StudentRepository;
import com.studentportal.service.MarksService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class MarksServiceImpl implements MarksService {

    private final MarksRepository marksRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    private final MarksMapper marksMapper;

    @Override
    public PageResponse<MarksDto> getAllMarks(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("student.firstName").ascending());
        Page<Marks> marksPage = marksRepository.findAllActive(pageable);

        return new PageResponse<>(
                marksPage.getContent().stream().map(marksMapper::toDto).toList(),
                marksPage.getNumber(),
                marksPage.getSize(),
                marksPage.getTotalElements(),
                marksPage.getTotalPages(),
                marksPage.isFirst(),
                marksPage.isLast()
        );
    }

    @Override
    public MarksDto getMarksById(Long id) {
        Marks marks = marksRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Marks not found with id: " + id));
        return marksMapper.toDto(marks);
    }

    @Override
    public MarksDto getMarksByStudentAndCourse(Long studentId, Long courseId) {
        Marks marks = marksRepository.findByStudentIdAndCourseId(studentId, courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Marks not found for student and course"));
        return marksMapper.toDto(marks);
    }

    @Override
    public List<MarksDto> getMarksByStudentId(Long studentId) {
        return marksRepository.findByStudentIdActive(studentId).stream()
                .map(marksMapper::toDto)
                .toList();
    }

    @Override
    public List<MarksDto> getMarksByCourseId(Long courseId) {
        return marksRepository.findByCourseIdActive(courseId).stream()
                .map(marksMapper::toDto)
                .toList();
    }

    @Override
    public MarksDto createMarks(MarksDto marksDto) {
        if (marksRepository.findByStudentIdAndCourseId(marksDto.getStudentId(), marksDto.getCourseId()).isPresent()) {
            throw new DuplicateResourceException("Marks already exist for this student and course");
        }

        Student student = studentRepository.findById(marksDto.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + marksDto.getStudentId()));
        
        Course course = courseRepository.findById(marksDto.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + marksDto.getCourseId()));

        Marks marks = marksMapper.toEntity(marksDto);
        marks.setStudent(student);
        marks.setCourse(course);
        
        if (marks.getExamDate() == null) {
            marks.setExamDate(LocalDate.now());
        }

        marks.setGrade(calculateGrade(marks.getScore(), marks.getMaxScore()));
        
        marks = marksRepository.save(marks);
        return marksMapper.toDto(marks);
    }

    @Override
    public MarksDto updateMarks(Long id, MarksDto marksDto) {
        Marks existingMarks = marksRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Marks not found with id: " + id));

        marksMapper.updateEntityFromDto(marksDto, existingMarks);
        existingMarks.setGrade(calculateGrade(existingMarks.getScore(), existingMarks.getMaxScore()));
        
        existingMarks = marksRepository.save(existingMarks);
        return marksMapper.toDto(existingMarks);
    }

    @Override
    public void deleteMarks(Long id) {
        Marks marks = marksRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Marks not found with id: " + id));
        marks.setDeleted(true);
        marksRepository.save(marks);
    }

    @Override
    public List<StudentRankingDto> getStudentRankings() {
        List<Marks> allMarks = marksRepository.findAllOrderByScoreDesc();
        
        Map<Long, List<Marks>> marksByStudent = allMarks.stream()
                .collect(Collectors.groupingBy(m -> m.getStudent().getId()));
        
        List<StudentRankingDto> rankings = new ArrayList<>();
        int rank = 1;
        
        for (Map.Entry<Long, List<Marks>> entry : marksByStudent.entrySet()) {
            Student student = studentRepository.findById(entry.getKey())
                    .orElseThrow(() -> new ResourceNotFoundException("Student not found"));
            
            List<Marks> studentMarks = entry.getValue();
            double averageScore = studentMarks.stream()
                    .mapToDouble(Marks::getScore)
                    .average()
                    .orElse(0.0);
            
            StudentRankingDto ranking = new StudentRankingDto();
            ranking.setId(student.getId());
            ranking.setRollNumber(student.getRollNumber());
            ranking.setFirstName(student.getFirstName());
            ranking.setLastName(student.getLastName());
            ranking.setDepartment(student.getDepartment());
            ranking.setAverageScore(averageScore);
            ranking.setRank(rank);
            ranking.setTotalCourses(studentMarks.size());
            
            rankings.add(ranking);
            rank++;
        }
        
        return rankings.stream()
                .sorted((a, b) -> Double.compare(b.getAverageScore(), a.getAverageScore()))
                .toList();
    }

    private String calculateGrade(Double score, Double maxScore) {
        if (maxScore == null || maxScore == 0) return "N/A";
        double percentage = (score / maxScore) * 100;
        
        if (percentage >= 90) return "A+";
        if (percentage >= 80) return "A";
        if (percentage >= 70) return "B";
        if (percentage >= 60) return "C";
        if (percentage >= 50) return "D";
        return "F";
    }
}
