package com.studentportal.service.impl;

import com.studentportal.dto.PageResponse;
import com.studentportal.dto.StudentDto;
import com.studentportal.entity.Student;
import com.studentportal.entity.User;
import com.studentportal.exception.DuplicateResourceException;
import com.studentportal.exception.ResourceNotFoundException;
import com.studentportal.mapper.StudentMapper;
import com.studentportal.repository.StudentRepository;
import com.studentportal.repository.UserRepository;
import com.studentportal.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;
    private final UserRepository userRepository;
    private final StudentMapper studentMapper;

    @Override
    public PageResponse<StudentDto> getAllStudents(int page, int size, String sortBy, String sortDir, String keyword) {
        Sort sort = sortDir.equalsIgnoreCase("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<Student> studentPage;
        if (keyword != null && !keyword.isEmpty()) {
            studentPage = studentRepository.searchStudents(keyword, pageable);
        } else {
            studentPage = studentRepository.findAllActive(pageable);
        }

        return new PageResponse<>(
                studentPage.getContent().stream().map(studentMapper::toDto).toList(),
                studentPage.getNumber(),
                studentPage.getSize(),
                studentPage.getTotalElements(),
                studentPage.getTotalPages(),
                studentPage.isFirst(),
                studentPage.isLast()
        );
    }

    @Override
    public StudentDto getStudentById(Long id) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
        return studentMapper.toDto(student);
    }

    @Override
    public StudentDto getStudentByRollNumber(String rollNumber) {
        Student student = studentRepository.findByRollNumber(rollNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with roll number: " + rollNumber));
        return studentMapper.toDto(student);
    }

    @Override
    public StudentDto createStudent(StudentDto studentDto) {
        if (studentRepository.existsByRollNumber(studentDto.getRollNumber())) {
            throw new DuplicateResourceException("Roll number already exists: " + studentDto.getRollNumber());
        }
        if (studentRepository.existsByEmail(studentDto.getEmail())) {
            throw new DuplicateResourceException("Email already exists: " + studentDto.getEmail());
        }

        Student student = studentMapper.toEntity(studentDto);

        if (studentDto.getUserId() != null) {
            User user = userRepository.findById(studentDto.getUserId())
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + studentDto.getUserId()));
            student.setUser(user);
        }

        student = studentRepository.save(student);
        return studentMapper.toDto(student);
    }

    @Override
    public StudentDto updateStudent(Long id, StudentDto studentDto) {
        Student existingStudent = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));

        if (!existingStudent.getRollNumber().equals(studentDto.getRollNumber()) && 
            studentRepository.existsByRollNumber(studentDto.getRollNumber())) {
            throw new DuplicateResourceException("Roll number already exists: " + studentDto.getRollNumber());
        }
        if (!existingStudent.getEmail().equals(studentDto.getEmail()) && 
            studentRepository.existsByEmail(studentDto.getEmail())) {
            throw new DuplicateResourceException("Email already exists: " + studentDto.getEmail());
        }

        studentMapper.updateEntityFromDto(studentDto, existingStudent);

        if (studentDto.getUserId() != null) {
            User user = userRepository.findById(studentDto.getUserId())
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + studentDto.getUserId()));
            existingStudent.setUser(user);
        }

        existingStudent = studentRepository.save(existingStudent);
        return studentMapper.toDto(existingStudent);
    }

    @Override
    public void deleteStudent(Long id) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
        student.setDeleted(true);
        studentRepository.save(student);
    }

    @Override
    public PageResponse<StudentDto> getStudentsByDepartment(String department, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("firstName").ascending());
        Page<Student> studentPage = studentRepository.findByDepartment(department, pageable);

        return new PageResponse<>(
                studentPage.getContent().stream().map(studentMapper::toDto).toList(),
                studentPage.getNumber(),
                studentPage.getSize(),
                studentPage.getTotalElements(),
                studentPage.getTotalPages(),
                studentPage.isFirst(),
                studentPage.isLast()
        );
    }
}
