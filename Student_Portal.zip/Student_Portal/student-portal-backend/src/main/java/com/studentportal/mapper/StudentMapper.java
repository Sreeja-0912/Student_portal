package com.studentportal.mapper;

import com.studentportal.dto.StudentDto;
import com.studentportal.entity.Student;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface StudentMapper {

    @Mapping(source = "user.id", target = "userId")
    @Mapping(source = "user.username", target = "username")
    StudentDto toDto(Student student);

    @Mapping(target = "user", ignore = true)
    Student toEntity(StudentDto studentDto);

    @Mapping(target = "user", ignore = true)
    void updateEntityFromDto(StudentDto studentDto, @MappingTarget Student student);
}
