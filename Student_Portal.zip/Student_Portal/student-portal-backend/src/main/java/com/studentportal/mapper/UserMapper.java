package com.studentportal.mapper;

import com.studentportal.dto.UserDto;
import com.studentportal.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface UserMapper {

    @Mapping(source = "role.id", target = "roleId")
    @Mapping(source = "role.name", target = "roleName")
    UserDto toDto(User user);

    @Mapping(target = "role", ignore = true)
    User toEntity(UserDto userDto);

    @Mapping(target = "role", ignore = true)
    void updateEntityFromDto(UserDto userDto, @MappingTarget User user);
}
