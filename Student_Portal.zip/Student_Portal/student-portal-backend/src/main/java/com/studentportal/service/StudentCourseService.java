package com.studentportal.service;

import com.studentportal.dto.StudentCourseDto;

import java.util.List;

public interface StudentCourseService {
    List<StudentCourseDto> getAllStudentCourses();
    List<StudentCourseDto> getStudentCoursesByStudentId(Long studentId);
    List<StudentCourseDto> getStudentCoursesByCourseId(Long courseId);
    StudentCourseDto enrollStudent(StudentCourseDto studentCourseDto);
    void unenrollStudent(Long studentId, Long courseId);
    StudentCourseDto updateEnrollment(Long id, StudentCourseDto studentCourseDto);
    void deleteEnrollment(Long id);
}
