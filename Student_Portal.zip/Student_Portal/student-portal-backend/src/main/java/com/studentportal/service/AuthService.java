package com.studentportal.service;

import com.studentportal.dto.LoginRequest;
import com.studentportal.dto.LoginResponse;

public interface AuthService {
    LoginResponse login(LoginRequest loginRequest);
}
