package com.studentportal.service;

import com.studentportal.dto.PageResponse;
import com.studentportal.dto.StudyMaterialDto;

import java.util.List;

public interface StudyMaterialService {
    PageResponse<StudyMaterialDto> getAllStudyMaterials(int page, int size);
    StudyMaterialDto getStudyMaterialById(Long id);
    List<StudyMaterialDto> getStudyMaterialsByCourseId(Long courseId);
    StudyMaterialDto createStudyMaterial(StudyMaterialDto studyMaterialDto);
    StudyMaterialDto updateStudyMaterial(Long id, StudyMaterialDto studyMaterialDto);
    void deleteStudyMaterial(Long id);
}
