package com.studentportal.mapper;

import com.studentportal.dto.AnnouncementDto;
import com.studentportal.entity.Announcement;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface AnnouncementMapper {

    @Mapping(source = "createdByUser", target = "createdBy")
    AnnouncementDto toDto(Announcement announcement);

    @Mapping(source = "createdBy", target = "createdByUser")
    Announcement toEntity(AnnouncementDto announcementDto);

    @Mapping(source = "createdBy", target = "createdByUser")
    void updateEntityFromDto(AnnouncementDto announcementDto, @MappingTarget Announcement announcement);
}
