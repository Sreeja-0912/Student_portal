package com.studentportal.repository;

import com.studentportal.entity.StudentCourse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentCourseRepository extends JpaRepository<StudentCourse, Long> {
    
    Optional<StudentCourse> findByStudentIdAndCourseId(Long studentId, Long courseId);
    
    List<StudentCourse> findByStudentId(Long studentId);
    List<StudentCourse> findByCourseId(Long courseId);
    
    @Query("SELECT sc FROM StudentCourse sc WHERE sc.student.id = :studentId AND sc.deleted = false")
    List<StudentCourse> findActiveByStudentId(@Param("studentId") Long studentId);
    
    @Query("SELECT sc FROM StudentCourse sc WHERE sc.course.id = :courseId AND sc.deleted = false")
    List<StudentCourse> findActiveByCourseId(@Param("courseId") Long courseId);
}
