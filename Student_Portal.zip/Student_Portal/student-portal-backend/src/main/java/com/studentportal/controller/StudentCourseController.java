package com.studentportal.controller;

import com.studentportal.dto.StudentCourseDto;
import com.studentportal.service.StudentCourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/student-courses")
@RequiredArgsConstructor
@Tag(name = "Student Course Management", description = "Student course enrollment APIs")
public class StudentCourseController {

    private final StudentCourseService studentCourseService;

    @GetMapping
    @Operation(summary = "Get all student courses", description = "Retrieve all student course enrollments")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<List<StudentCourseDto>> getAllStudentCourses() {
        return ResponseEntity.ok(studentCourseService.getAllStudentCourses());
    }

    @GetMapping("/student/{studentId}")
    @Operation(summary = "Get courses by student", description = "Retrieve courses enrolled by a specific student")
    public ResponseEntity<List<StudentCourseDto>> getStudentCoursesByStudentId(@PathVariable Long studentId) {
        return ResponseEntity.ok(studentCourseService.getStudentCoursesByStudentId(studentId));
    }

    @GetMapping("/course/{courseId}")
    @Operation(summary = "Get students by course", description = "Retrieve students enrolled in a specific course")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<List<StudentCourseDto>> getStudentCoursesByCourseId(@PathVariable Long courseId) {
        return ResponseEntity.ok(studentCourseService.getStudentCoursesByCourseId(courseId));
    }

    @PostMapping
    @Operation(summary = "Enroll student in course", description = "Enroll a student in a course")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<StudentCourseDto> enrollStudent(@Valid @RequestBody StudentCourseDto studentCourseDto) {
        return ResponseEntity.ok(studentCourseService.enrollStudent(studentCourseDto));
    }

    @DeleteMapping("/student/{studentId}/course/{courseId}")
    @Operation(summary = "Unenroll student from course", description = "Unenroll a student from a course")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<Void> unenrollStudent(@PathVariable Long studentId, @PathVariable Long courseId) {
        studentCourseService.unenrollStudent(studentId, courseId);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update enrollment", description = "Update student course enrollment")
    @PreAuthorize("hasAnyRole('ADMIN', 'FACULTY')")
    public ResponseEntity<StudentCourseDto> updateEnrollment(@PathVariable Long id, @Valid @RequestBody StudentCourseDto studentCourseDto) {
        return ResponseEntity.ok(studentCourseService.updateEnrollment(id, studentCourseDto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete enrollment", description = "Delete a student course enrollment")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteEnrollment(@PathVariable Long id) {
        studentCourseService.deleteEnrollment(id);
        return ResponseEntity.noContent().build();
    }
}
