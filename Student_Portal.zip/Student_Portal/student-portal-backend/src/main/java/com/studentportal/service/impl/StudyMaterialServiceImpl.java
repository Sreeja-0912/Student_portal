package com.studentportal.service.impl;

import com.studentportal.dto.PageResponse;
import com.studentportal.dto.StudyMaterialDto;
import com.studentportal.entity.Course;
import com.studentportal.entity.StudyMaterial;
import com.studentportal.exception.ResourceNotFoundException;
import com.studentportal.mapper.StudyMaterialMapper;
import com.studentportal.repository.CourseRepository;
import com.studentportal.repository.StudyMaterialRepository;
import com.studentportal.service.StudyMaterialService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class StudyMaterialServiceImpl implements StudyMaterialService {

    private final StudyMaterialRepository studyMaterialRepository;
    private final CourseRepository courseRepository;
    private final StudyMaterialMapper studyMaterialMapper;

    @Override
    public PageResponse<StudyMaterialDto> getAllStudyMaterials(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("uploadDate").descending());
        Page<StudyMaterial> studyMaterialPage = studyMaterialRepository.findAllActive(pageable);

        return new PageResponse<>(
                studyMaterialPage.getContent().stream().map(studyMaterialMapper::toDto).toList(),
                studyMaterialPage.getNumber(),
                studyMaterialPage.getSize(),
                studyMaterialPage.getTotalElements(),
                studyMaterialPage.getTotalPages(),
                studyMaterialPage.isFirst(),
                studyMaterialPage.isLast()
        );
    }

    @Override
    public StudyMaterialDto getStudyMaterialById(Long id) {
        StudyMaterial studyMaterial = studyMaterialRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Study material not found with id: " + id));
        return studyMaterialMapper.toDto(studyMaterial);
    }

    @Override
    public List<StudyMaterialDto> getStudyMaterialsByCourseId(Long courseId) {
        return studyMaterialRepository.findActiveByCourseId(courseId).stream()
                .map(studyMaterialMapper::toDto)
                .toList();
    }

    @Override
    public StudyMaterialDto createStudyMaterial(StudyMaterialDto studyMaterialDto) {
        Course course = courseRepository.findById(studyMaterialDto.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with id: " + studyMaterialDto.getCourseId()));

        StudyMaterial studyMaterial = studyMaterialMapper.toEntity(studyMaterialDto);
        studyMaterial.setCourse(course);
        studyMaterial.setUploadDate(LocalDate.now());
        
        studyMaterial = studyMaterialRepository.save(studyMaterial);
        return studyMaterialMapper.toDto(studyMaterial);
    }

    @Override
    public StudyMaterialDto updateStudyMaterial(Long id, StudyMaterialDto studyMaterialDto) {
        StudyMaterial existingMaterial = studyMaterialRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Study material not found with id: " + id));

        studyMaterialMapper.updateEntityFromDto(studyMaterialDto, existingMaterial);
        existingMaterial = studyMaterialRepository.save(existingMaterial);
        return studyMaterialMapper.toDto(existingMaterial);
    }

    @Override
    public void deleteStudyMaterial(Long id) {
        StudyMaterial studyMaterial = studyMaterialRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Study material not found with id: " + id));
        studyMaterial.setDeleted(true);
        studyMaterialRepository.save(studyMaterial);
    }
}
