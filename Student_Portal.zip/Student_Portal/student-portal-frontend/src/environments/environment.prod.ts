export const environment = {
  production: true,
  apiUrl: 'https://api.studentportal.com/api'
};
