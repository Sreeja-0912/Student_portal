import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { StudentsComponent } from './components/students/students.component';
import { CoursesComponent } from './components/courses/courses.component';
import { AttendanceComponent } from './components/attendance/attendance.component';
import { MarksComponent } from './components/marks/marks.component';
import { AnnouncementsComponent } from './components/announcements/announcements.component';
import { StudyMaterialsComponent } from './components/study-materials/study-materials.component';
import { ReportsComponent } from './components/reports/reports.component';
import { ProfileComponent } from './components/profile/profile.component';
import { LayoutComponent } from './components/layout/layout.component';
import { AuthGuard } from './guards/auth.guard';
import { RoleGuard } from './guards/role.guard';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: '',
    component: LayoutComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'students', component: StudentsComponent },
      { path: 'courses', component: CoursesComponent, canActivate: [RoleGuard], data: { allowedRoles: ['ADMIN', 'FACULTY'] } },
      { path: 'attendance', component: AttendanceComponent },
      { path: 'marks', component: MarksComponent },
      { path: 'announcements', component: AnnouncementsComponent },
      { path: 'study-materials', component: StudyMaterialsComponent },
      { path: 'reports', component: ReportsComponent, canActivate: [RoleGuard], data: { allowedRoles: ['ADMIN', 'FACULTY'] } },
      { path: 'profile', component: ProfileComponent }
    ]
  },
  { path: '**', redirectTo: '/login' }
];
