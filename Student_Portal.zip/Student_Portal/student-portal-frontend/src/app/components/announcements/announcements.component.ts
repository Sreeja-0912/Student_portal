import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-announcements',
  templateUrl: './announcements.component.html',
  styleUrls: ['./announcements.component.css']
})
export class AnnouncementsComponent implements OnInit {
  announcements: any[] = [];
  loading = false;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadAnnouncements();
  }

  loadAnnouncements(): void {
    this.loading = true;
    this.apiService.getAnnouncementsByTargetAudience('ALL').subscribe({
      next: (data) => {
        this.announcements = data;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading announcements:', error);
        this.loading = false;
      }
    });
  }
}
