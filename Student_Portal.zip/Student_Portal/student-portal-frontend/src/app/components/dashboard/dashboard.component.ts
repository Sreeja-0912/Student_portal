import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { DashboardSummary } from '../../models/dashboard.model';
import { StudentRanking } from '../../models/marks.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  summary: DashboardSummary | null = null;
  topStudents: StudentRanking[] = [];
  lowAttendanceStudents: StudentRanking[] = [];
  atRiskStudents: StudentRanking[] = [];
  loading = true;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadDashboardData();
  }

  loadDashboardData(): void {
    this.loading = true;
    
    this.apiService.getDashboardSummary().subscribe({
      next: (data) => {
        this.summary = data;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading dashboard summary:', error);
        this.loading = false;
      }
    });

    this.apiService.getTopStudents(5).subscribe({
      next: (data) => {
        this.topStudents = data;
      },
      error: (error) => console.error('Error loading top students:', error)
    });

    this.apiService.getLowAttendanceStudents(75).subscribe({
      next: (data) => {
        this.lowAttendanceStudents = data;
      },
      error: (error) => console.error('Error loading low attendance students:', error)
    });

    this.apiService.getAtRiskStudents().subscribe({
      next: (data) => {
        this.atRiskStudents = data;
      },
      error: (error) => console.error('Error loading at-risk students:', error)
    });
  }
}
