import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Course, PageResponse } from '../../models/course.model';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
  courses: Course[] = [];
  pageResponse: PageResponse<Course> | null = null;
  loading = false;
  currentPage = 0;
  pageSize = 10;
  searchKeyword = '';

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadCourses();
  }

  loadCourses(): void {
    this.loading = true;
    this.apiService.getCourses(this.currentPage, this.pageSize, 'courseCode', 'asc', this.searchKeyword).subscribe({
      next: (response) => {
        this.pageResponse = response;
        this.courses = response.content;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading courses:', error);
        this.loading = false;
      }
    });
  }

  onSearch(): void {
    this.currentPage = 0;
    this.loadCourses();
  }

  onPageChange(event: any): void {
    this.currentPage = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadCourses();
  }
}
