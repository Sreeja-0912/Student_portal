import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-study-materials',
  templateUrl: './study-materials.component.html',
  styleUrls: ['./study-materials.component.css']
})
export class StudyMaterialsComponent implements OnInit {
  studyMaterials: any[] = [];
  loading = false;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadStudyMaterials();
  }

  loadStudyMaterials(): void {
    this.loading = true;
    this.apiService.getStudyMaterialsByCourseId(1).subscribe({
      next: (data) => {
        this.studyMaterials = data;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading study materials:', error);
        this.loading = false;
      }
    });
  }
}
