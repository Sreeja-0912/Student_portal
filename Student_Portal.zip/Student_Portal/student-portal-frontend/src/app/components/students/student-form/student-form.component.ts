import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ApiService } from '../../../services/api.service';
import { Student } from '../../../models/student.model';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent {
  studentForm: FormGroup;
  mode: 'add' | 'edit' = 'add';
  loading = false;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<StudentFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private apiService: ApiService,
    private snackBar: MatSnackBar
  ) {
    this.mode = data.mode || 'add';
    this.studentForm = this.createForm();
    
    if (this.mode === 'edit' && data.student) {
      this.studentForm.patchValue(data.student);
    }
  }

  createForm(): FormGroup {
    return this.fb.group({
      id: [null],
      rollNumber: ['', [Validators.required, Validators.minLength(3)]],
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      department: ['', [Validators.required]],
      semester: ['', [Validators.required, Validators.min(1), Validators.max(8)]]
    });
  }

  onSubmit(): void {
    if (this.studentForm.invalid) {
      return;
    }

    this.loading = true;
    const student: Student = this.studentForm.value;

    if (this.mode === 'add') {
      this.apiService.createStudent(student).subscribe({
        next: () => {
          this.loading = false;
          this.snackBar.open('Student created successfully', 'Close', { duration: 3000 });
          this.dialogRef.close(true);
        },
        error: (error) => {
          this.loading = false;
          this.snackBar.open('Error creating student: ' + error.error.message, 'Close', { duration: 5000 });
        }
      });
    } else {
      this.apiService.updateStudent(student.id!, student).subscribe({
        next: () => {
          this.loading = false;
          this.snackBar.open('Student updated successfully', 'Close', { duration: 3000 });
          this.dialogRef.close(true);
        },
        error: (error) => {
          this.loading = false;
          this.snackBar.open('Error updating student: ' + error.error.message, 'Close', { duration: 5000 });
        }
      });
    }
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}
