import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Attendance } from '../../models/attendance.model';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {
  attendanceRecords: Attendance[] = [];
  loading = false;
  currentUserId: number | null = null;

  constructor(private apiService: ApiService) {
    this.currentUserId = this.getUserIdFromToken();
  }

  ngOnInit(): void {
    if (this.currentUserId) {
      this.loadAttendance();
    }
  }

  getUserIdFromToken(): number | null {
    const userStr = localStorage.getItem('current_user');
    if (userStr) {
      const user = JSON.parse(userStr);
      return user.userId;
    }
    return null;
  }

  loadAttendance(): void {
    this.loading = true;
    this.apiService.getAttendanceByStudentId(this.currentUserId!).subscribe({
      next: (data) => {
        this.attendanceRecords = data;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading attendance:', error);
        this.loading = false;
      }
    });
  }
}
