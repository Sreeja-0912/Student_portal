import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  departmentPerformance: any = null;
  passFailStats: any = null;
  attendanceStats: any = null;
  loading = false;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadReports();
  }

  loadReports(): void {
    this.loading = true;
    
    this.apiService.getDepartmentPerformance().subscribe({
      next: (data) => {
        this.departmentPerformance = data;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading department performance:', error);
        this.loading = false;
      }
    });

    this.apiService.getPassFailStatistics().subscribe({
      next: (data) => {
        this.passFailStats = data;
      },
      error: (error) => console.error('Error loading pass/fail stats:', error)
    });

    this.apiService.getAttendanceStatistics().subscribe({
      next: (data) => {
        this.attendanceStats = data;
      },
      error: (error) => console.error('Error loading attendance stats:', error)
    });
  }
}
