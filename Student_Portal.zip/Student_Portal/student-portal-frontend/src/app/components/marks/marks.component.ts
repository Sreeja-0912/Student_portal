import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Marks } from '../../models/marks.model';

@Component({
  selector: 'app-marks',
  templateUrl: './marks.component.html',
  styleUrls: ['./marks.component.css']
})
export class MarksComponent implements OnInit {
  marksRecords: Marks[] = [];
  loading = false;
  currentUserId: number | null = null;

  constructor(private apiService: ApiService) {
    this.currentUserId = this.getUserIdFromToken();
  }

  ngOnInit(): void {
    if (this.currentUserId) {
      this.loadMarks();
    }
  }

  getUserIdFromToken(): number | null {
    const userStr = localStorage.getItem('current_user');
    if (userStr) {
      const user = JSON.parse(userStr);
      return user.userId;
    }
    return null;
  }

  loadMarks(): void {
    this.loading = true;
    this.apiService.getMarksByStudentId(this.currentUserId!).subscribe({
      next: (data) => {
        this.marksRecords = data;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading marks:', error);
        this.loading = false;
      }
    });
  }
}
