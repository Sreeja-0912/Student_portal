export interface Course {
  id?: number;
  courseCode: string;
  courseName: string;
  credits: number;
  facultyName?: string;
}
