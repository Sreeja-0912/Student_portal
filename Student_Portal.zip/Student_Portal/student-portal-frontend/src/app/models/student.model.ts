export interface Student {
  id?: number;
  rollNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  department: string;
  semester: number;
  userId?: number;
  username?: string;
}

export interface PageResponse<T> {
  content: T[];
  pageNumber: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
}
