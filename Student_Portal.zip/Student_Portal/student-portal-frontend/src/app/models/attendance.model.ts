export interface Attendance {
  id?: number;
  studentId: number;
  studentName: string;
  rollNumber: string;
  courseId: number;
  courseCode: string;
  courseName: string;
  attendancePercentage: number;
  totalClasses?: number;
  attendedClasses?: number;
}
