export interface DashboardSummary {
  totalStudents: number;
  totalCourses: number;
  averageAttendance: number;
  passPercentage: number;
  totalFaculty: number;
  totalAnnouncements: number;
}
