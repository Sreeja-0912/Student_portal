export interface Marks {
  id?: number;
  studentId: number;
  studentName: string;
  rollNumber: string;
  courseId: number;
  courseCode: string;
  courseName: string;
  score: number;
  maxScore?: number;
  grade?: string;
  examDate?: string;
}

export interface StudentRanking {
  id: number;
  rollNumber: string;
  firstName: string;
  lastName: string;
  department: string;
  averageScore: number;
  rank: number;
  totalCourses: number;
}
