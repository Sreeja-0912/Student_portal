import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Student, PageResponse } from '../models/student.model';
import { Course } from '../models/course.model';
import { Attendance } from '../models/attendance.model';
import { Marks, StudentRanking } from '../models/marks.model';
import { DashboardSummary } from '../models/dashboard.model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private readonly apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // Student APIs
  getStudents(page: number = 0, size: number = 10, sortBy: string = 'firstName', 
              sortDir: string = 'asc', keyword?: string): Observable<PageResponse<Student>> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString())
      .set('sortBy', sortBy)
      .set('sortDir', sortDir);
    
    if (keyword) {
      params = params.set('keyword', keyword);
    }
    
    return this.http.get<PageResponse<Student>>(`${this.apiUrl}/students`, { params });
  }

  getStudentById(id: number): Observable<Student> {
    return this.http.get<Student>(`${this.apiUrl}/students/${id}`);
  }

  createStudent(student: Student): Observable<Student> {
    return this.http.post<Student>(`${this.apiUrl}/students`, student);
  }

  updateStudent(id: number, student: Student): Observable<Student> {
    return this.http.put<Student>(`${this.apiUrl}/students/${id}`, student);
  }

  deleteStudent(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/students/${id}`);
  }

  // Course APIs
  getCourses(page: number = 0, size: number = 10, sortBy: string = 'courseCode',
             sortDir: string = 'asc', keyword?: string): Observable<PageResponse<Course>> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString())
      .set('sortBy', sortBy)
      .set('sortDir', sortDir);
    
    if (keyword) {
      params = params.set('keyword', keyword);
    }
    
    return this.http.get<PageResponse<Course>>(`${this.apiUrl}/courses`, { params });
  }

  getCourseById(id: number): Observable<Course> {
    return this.http.get<Course>(`${this.apiUrl}/courses/${id}`);
  }

  createCourse(course: Course): Observable<Course> {
    return this.http.post<Course>(`${this.apiUrl}/courses`, course);
  }

  updateCourse(id: number, course: Course): Observable<Course> {
    return this.http.put<Course>(`${this.apiUrl}/courses/${id}`, course);
  }

  deleteCourse(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/courses/${id}`);
  }

  // Attendance APIs
  getAttendanceByStudentId(studentId: number): Observable<Attendance[]> {
    return this.http.get<Attendance[]>(`${this.apiUrl}/attendance/student/${studentId}`);
  }

  createAttendance(attendance: Attendance): Observable<Attendance> {
    return this.http.post<Attendance>(`${this.apiUrl}/attendance`, attendance);
  }

  updateAttendance(id: number, attendance: Attendance): Observable<Attendance> {
    return this.http.put<Attendance>(`${this.apiUrl}/attendance/${id}`, attendance);
  }

  getDefaulters(): Observable<Attendance[]> {
    return this.http.get<Attendance[]>(`${this.apiUrl}/attendance/defaulters`);
  }

  // Marks APIs
  getMarksByStudentId(studentId: number): Observable<Marks[]> {
    return this.http.get<Marks[]>(`${this.apiUrl}/marks/student/${studentId}`);
  }

  createMarks(marks: Marks): Observable<Marks> {
    return this.http.post<Marks>(`${this.apiUrl}/marks`, marks);
  }

  updateMarks(id: number, marks: Marks): Observable<Marks> {
    return this.http.put<Marks>(`${this.apiUrl}/marks/${id}`, marks);
  }

  getStudentRankings(): Observable<StudentRanking[]> {
    return this.http.get<StudentRanking[]>(`${this.apiUrl}/marks/rankings`);
  }

  // Dashboard APIs
  getDashboardSummary(): Observable<DashboardSummary> {
    return this.http.get<DashboardSummary>(`${this.apiUrl}/dashboard/summary`);
  }

  getTopStudents(limit: number = 10): Observable<StudentRanking[]> {
    return this.http.get<StudentRanking[]>(`${this.apiUrl}/dashboard/top-students?limit=${limit}`);
  }

  getLowAttendanceStudents(threshold: number = 75): Observable<StudentRanking[]> {
    return this.http.get<StudentRanking[]>(`${this.apiUrl}/dashboard/low-attendance?threshold=${threshold}`);
  }

  getAtRiskStudents(): Observable<StudentRanking[]> {
    return this.http.get<StudentRanking[]>(`${this.apiUrl}/dashboard/at-risk-students`);
  }

  getDepartmentPerformance(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/dashboard/department-performance`);
  }

  getPassFailStatistics(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/dashboard/pass-fail-stats`);
  }

  getAttendanceStatistics(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/dashboard/attendance-stats`);
  }
}
