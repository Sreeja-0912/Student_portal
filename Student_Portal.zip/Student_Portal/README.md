# Student Portal Management System

A comprehensive full-stack Student Portal Management System built with modern technologies, featuring role-based authentication, comprehensive student management, and advanced reporting capabilities.

## 🚀 Tech Stack

### Backend
- **Java 21** - Programming language
- **Spring Boot 3.2.0** - Application framework
- **Spring Security 6** - Security framework with JWT authentication
- **Spring Data JPA** - Data persistence with Hibernate
- **MySQL 8** - Database
- **Maven** - Build tool
- **Swagger/OpenAPI 3** - API documentation
- **MapStruct** - Bean mapping
- **Lombok** - Code generation
- **JUnit 5 & Mockito** - Testing

### Frontend
- **Angular 18** - Frontend framework
- **Angular Material** - UI component library
- **TypeScript 5.4** - Programming language
- **RxJS** - Reactive programming
- **Angular Charts** - Data visualization

### DevOps
- **Docker** - Containerization
- **Docker Compose** - Multi-container orchestration
- **GitHub Actions** - CI/CD pipeline
- **Render** - Cloud deployment

## 📋 Features

### Role-Based Access Control
- **ADMIN** - Full system access
- **FACULTY** - Attendance, marks, and reports management
- **STUDENT** - View profile, attendance, marks, and study materials

### Core Modules
1. **Authentication** - JWT-based secure login
2. **Student Management** - Complete CRUD operations with search and pagination
3. **Course Management** - Course catalog and enrollment
4. **Attendance Tracking** - Monitor student attendance with defaulter detection
5. **Marks Management** - Grade tracking and student rankings
6. **Announcements** - System-wide notifications
7. **Study Materials** - Course resources and downloads
8. **Dashboard** - Real-time analytics and statistics
9. **Reports** - Comprehensive reporting with charts
10. **Profile Management** - User profile settings

### Advanced Features
- **Pagination & Sorting** - Efficient data handling
- **Search Functionality** - Quick data lookup
- **Soft Delete** - Data retention
- **Audit Logging** - Activity tracking
- **Exception Handling** - Global error management
- **API Documentation** - Interactive Swagger UI
- **Responsive Design** - Mobile-friendly interface

## 🏗️ Project Structure

```
student-portal/
├── student-portal-backend/
│   ├── src/main/java/com/studentportal/
│   │   ├── config/          # Security and configuration
│   │   ├── controller/      # REST API controllers
│   │   ├── dto/             # Data transfer objects
│   │   ├── entity/          # JPA entities
│   │   ├── exception/       # Custom exceptions
│   │   ├── mapper/          # MapStruct mappers
│   │   ├── repository/      # JPA repositories
│   │   ├── security/        # JWT and security
│   │   └── service/         # Business logic
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
├── student-portal-frontend/
│   ├── src/app/
│   │   ├── components/      # Angular components
│   │   ├── guards/          # Route guards
│   │   ├── interceptors/    # HTTP interceptors
│   │   ├── models/          # TypeScript models
│   │   ├── services/        # API services
│   │   └── ...
│   ├── angular.json
│   └── package.json
├── docker-compose.yml
├── .github/workflows/ci-cd.yml
└── README.md
```

## 🚀 Getting Started

### Prerequisites
- Java 21+
- Node.js 20+
- MySQL 8+
- Maven 3.9+
- Docker & Docker Compose

### Backend Setup

1. **Clone the repository**
```bash
git clone <repository-url>
cd student-portal
```

2. **Configure Database**
```bash
# Update backend/src/main/resources/application.properties
spring.datasource.url=jdbc:mysql://localhost:3306/student_portal
spring.datasource.username=root
spring.datasource.password=your_password
```

3. **Build and Run Backend**
```bash
cd student-portal-backend
mvn clean install
mvn spring-boot:run
```

Backend will be available at `http://localhost:8080`

### Frontend Setup

1. **Install Dependencies**
```bash
cd student-portal-frontend
npm install
```

2. **Run Development Server**
```bash
ng serve
```

Frontend will be available at `http://localhost:4200`

### Docker Setup

1. **Build and Run with Docker Compose**
```bash
docker-compose up --build
```

This will start:
- MySQL on port 3306
- Backend on port 8080
- Frontend on port 80

## 🔐 Default Credentials

- **Username**: `admin`
- **Password**: `admin123`

## 📚 API Documentation

Swagger UI is available at: `http://localhost:8080/swagger-ui.html`

### Key API Endpoints

#### Authentication
- `POST /api/auth/login` - User login

#### Students
- `GET /api/students` - Get all students (with pagination)
- `GET /api/students/{id}` - Get student by ID
- `POST /api/students` - Create new student
- `PUT /api/students/{id}` - Update student
- `DELETE /api/students/{id}` - Delete student

#### Courses
- `GET /api/courses` - Get all courses
- `POST /api/courses` - Create new course
- `PUT /api/courses/{id}` - Update course
- `DELETE /api/courses/{id}` - Delete course

#### Attendance
- `GET /api/attendance/student/{id}` - Get student attendance
- `POST /api/attendance` - Create attendance record
- `GET /api/attendance/defaulters` - Get attendance defaulters

#### Marks
- `GET /api/marks/student/{id}` - Get student marks
- `POST /api/marks` - Create marks record
- `GET /api/marks/rankings` - Get student rankings

#### Dashboard
- `GET /api/dashboard/summary` - Dashboard summary
- `GET /api/dashboard/top-students` - Top performing students
- `GET /api/dashboard/low-attendance` - Low attendance students
- `GET /api/dashboard/at-risk-students` - At-risk students

## 🧪 Testing

### Backend Tests
```bash
cd student-portal-backend
mvn test
```

### Frontend Tests
```bash
cd student-portal-frontend
npm test
```

## 📦 Deployment

### Render Deployment
1. Connect your GitHub repository to Render
2. Configure environment variables
3. Deploy automatically on push to main branch

### Manual Deployment
```bash
# Build Docker images
docker build -t student-portal-backend ./student-portal-backend
docker build -t student-portal-frontend ./student-portal-frontend

# Push to Docker Hub
docker push your-username/student-portal-backend
docker push your-username/student-portal-frontend
```

## 🔧 Configuration

### Environment Variables

**Backend:**
- `SPRING_DATASOURCE_URL` - Database connection URL
- `SPRING_DATASOURCE_USERNAME` - Database username
- `SPRING_DATASOURCE_PASSWORD` - Database password
- `JWT_SECRET` - JWT signing secret
- `JWT_EXPIRATION` - Token expiration time (ms)

**Frontend:**
- `apiUrl` - Backend API URL

## 📊 Database Schema

### Tables
- `roles` - User roles (ADMIN, FACULTY, STUDENT)
- `users` - System users with authentication
- `students` - Student information
- `courses` - Course catalog
- `student_courses` - Student-course enrollments
- `attendance` - Attendance records
- `marks` - Student marks and grades
- `announcements` - System announcements
- `study_materials` - Course resources
- `audit_logs` - System activity logs

## 🛠️ Development

### Code Style
- Backend: Java code conventions
- Frontend: Angular style guide
- Commit messages: Conventional commits

### Branching Strategy
- `main` - Production branch
- `develop` - Development branch
- `feature/*` - Feature branches
- `bugfix/*` - Bug fix branches

## 📝 License

This project is licensed under the MIT License.

## 👥 Team

Student Portal Development Team

## 📞 Support

For support, email support@studentportal.com or open an issue in the repository.
