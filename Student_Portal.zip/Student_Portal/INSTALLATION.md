# Installation Guide

## System Requirements

### Minimum Requirements
- **OS**: Windows 10+, macOS 10.15+, or Linux (Ubuntu 20.04+)
- **RAM**: 8GB minimum, 16GB recommended
- **Disk Space**: 10GB free space
- **Processor**: Dual-core processor or better

### Software Requirements
- **Java Development Kit (JDK)**: Version 21
- **Node.js**: Version 20 or higher
- **Maven**: Version 3.9 or higher
- **MySQL**: Version 8.0 or higher
- **Git**: Version 2.30 or higher
- **Docker**: Version 24.0 or higher (optional)
- **Docker Compose**: Version 2.20 or higher (optional)

## Installation Steps

### 1. Install Java 21

#### Windows
1. Download JDK 21 from [Oracle](https://www.oracle.com/java/technologies/downloads/#java21)
2. Run the installer
3. Set JAVA_HOME environment variable
4. Add Java bin directory to PATH

#### macOS
```bash
brew install openjdk@21
```

#### Linux (Ubuntu)
```bash
sudo apt update
sudo apt install openjdk-21-jdk
```

Verify installation:
```bash
java -version
```

### 2. Install Node.js 20

#### Windows
1. Download from [nodejs.org](https://nodejs.org/)
2. Run the installer

#### macOS
```bash
brew install node
```

#### Linux (Ubuntu)
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

Verify installation:
```bash
node -v
npm -v
```

### 3. Install Maven

#### Windows
1. Download from [maven.apache.org](https://maven.apache.org/download.cgi)
2. Extract to desired location
3. Set MAVEN_HOME environment variable
4. Add Maven bin directory to PATH

#### macOS
```bash
brew install maven
```

#### Linux (Ubuntu)
```bash
sudo apt install maven
```

Verify installation:
```bash
mvn -v
```

### 4. Install MySQL 8

#### Windows
1. Download from [mysql.com](https://dev.mysql.com/downloads/mysql/)
2. Run the installer
3. Set root password during installation

#### macOS
```bash
brew install mysql
brew services start mysql
```

#### Linux (Ubuntu)
```bash
sudo apt update
sudo apt install mysql-server
sudo mysql_secure_installation
```

Verify installation:
```bash
mysql --version
```

### 5. Install Docker (Optional but Recommended)

#### Windows
1. Download Docker Desktop from [docker.com](https://www.docker.com/products/docker-desktop)
2. Run the installer
3. Restart your computer

#### macOS
```bash
brew install --cask docker
```

#### Linux (Ubuntu)
```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER
```

Verify installation:
```bash
docker --version
docker-compose --version
```

## Project Setup

### 1. Clone the Repository

```bash
git clone <repository-url>
cd student-portal
```

### 2. Database Setup

#### Create MySQL Database
```bash
mysql -u root -p
```

```sql
CREATE DATABASE student_portal;
CREATE USER 'student_portal'@'localhost' IDENTIFIED BY 'student_portal';
GRANT ALL PRIVILEGES ON student_portal.* TO 'student_portal'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 3. Backend Configuration

#### Navigate to Backend Directory
```bash
cd student-portal-backend
```

#### Update Application Properties
Edit `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/student_portal?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=student_portal
spring.datasource.password=student_portal
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

jwt.secret=your-secret-key-here
jwt.expiration=86400000
```

#### Build Backend
```bash
mvn clean install
```

#### Run Backend
```bash
mvn spring-boot:run
```

Backend will be available at `http://localhost:8080`

### 4. Frontend Configuration

#### Navigate to Frontend Directory
```bash
cd student-portal-frontend
```

#### Install Dependencies
```bash
npm install
```

#### Update API URL (if needed)
Edit `src/environments/environment.ts`:

```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api'
};
```

#### Run Frontend Development Server
```bash
ng serve
```

Frontend will be available at `http://localhost:4200`

## Docker Setup (Alternative)

If you prefer using Docker, you can skip the manual setup:

### 1. Build and Run with Docker Compose

```bash
docker-compose up --build
```

This will:
- Create and start MySQL container
- Build and start Backend container
- Build and start Frontend container
- Configure networking between containers

### 2. Access the Application

- Frontend: `http://localhost:80`
- Backend API: `http://localhost:8080`
- Swagger UI: `http://localhost:8080/swagger-ui.html`

### 3. Stop Containers

```bash
docker-compose down
```

### 4. Remove Volumes (Complete Cleanup)

```bash
docker-compose down -v
```

## Verification

### 1. Check Backend Health

```bash
curl http://localhost:8080/actuator/health
```

Expected response:
```json
{
  "status": "UP"
}
```

### 2. Check Swagger UI

Open browser: `http://localhost:8080/swagger-ui.html`

### 3. Test Login

Use default credentials:
- Username: `admin`
- Password: `admin123`

### 4. Check Frontend

Open browser: `http://localhost:4200` (or `http://localhost` for Docker)

## Troubleshooting

### Port Already in Use

**Windows:**
```powershell
netstat -ano | findstr :8080
taskkill /PID <PID> /F
```

**Linux/macOS:**
```bash
lsof -ti:8080 | xargs kill -9
```

### MySQL Connection Issues

1. Check MySQL service is running
2. Verify credentials in application.properties
3. Check firewall settings
4. Ensure MySQL allows remote connections

### Maven Build Failures

1. Clear Maven cache: `mvn clean`
2. Update Maven dependencies: `mvn dependency:purge-local-repository`
3. Check Java version compatibility

### npm Install Failures

1. Clear npm cache: `npm cache clean --force`
2. Delete node_modules and package-lock.json
3. Reinstall: `npm install`

### Docker Build Failures

1. Ensure Docker daemon is running
2. Check disk space availability
3. Verify Dockerfile syntax
4. Check network connectivity

## Next Steps

After successful installation:

1. **Create Initial Data**
   - Login as admin
   - Create faculty accounts
   - Add courses
   - Enroll students

2. **Configure Roles**
   - Assign appropriate roles to users
   - Set up permissions

3. **Customize Settings**
   - Update JWT secret
   - Configure email settings
   - Set up backup procedures

## Support

For installation issues:
- Check the [Troubleshooting](#troubleshooting) section
- Review GitHub Issues
- Contact support at support@studentportal.com
