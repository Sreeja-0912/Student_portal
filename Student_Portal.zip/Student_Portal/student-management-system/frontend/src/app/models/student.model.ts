export interface Student {
  id?: number;
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  phoneNumber: string;
  dateOfBirth: string;
  gender: string;
  active: boolean;
}
