import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { StudentService } from '../../services/student.service';
import { Student } from '../../models/student.model';

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.css'
})
export class StudentListComponent implements OnInit {
  students: Student[] = [];
  searchTerm = '';
  loading = false;
  errorMessage = '';

  constructor(private studentService: StudentService, private router: Router) {}

  ngOnInit(): void {
    this.loadStudents();
  }

  loadStudents(): void {
    this.loading = true;
    this.errorMessage = '';
    this.studentService.getStudents(this.searchTerm || undefined).subscribe({
      next: data => {
        this.students = data;
        this.loading = false;
      },
      error: () => {
        this.errorMessage = 'Unable to load students.';
        this.loading = false;
      }
    });
  }

  deleteStudent(id?: number): void {
    if (!id) return;
    const ok = confirm('Delete this student?');
    if (!ok) return;
    this.studentService.deleteStudent(id).subscribe({
      next: () => this.loadStudents(),
      error: () => this.errorMessage = 'Delete failed.'
    });
  }
}
