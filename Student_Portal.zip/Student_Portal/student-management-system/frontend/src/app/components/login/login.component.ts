import { Component } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  errorMessage = '';

  form = this.fb.group({
    username: ['admin', Validators.required],
    password: ['admin123', Validators.required]
  });

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {}

  submit(): void {
    this.errorMessage = '';
    if (this.form.invalid) {
      this.errorMessage = 'Please enter username and password.';
      return;
    }
    this.authService.login({
      username: this.form.value.username ?? '',
      password: this.form.value.password ?? ''
    }).subscribe({
      next: () => this.router.navigateByUrl('/students'),
      error: () => this.errorMessage = 'Invalid username or password.'
    });
  }
}
