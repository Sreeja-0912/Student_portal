import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { StudentService } from '../../services/student.service';
import { Student } from '../../models/student.model';

@Component({
  selector: 'app-student-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './student-form.component.html',
  styleUrl: './student-form.component.css'
})
export class StudentFormComponent implements OnInit {
  studentId?: number;
  pageTitle = 'Add Student';
  errorMessage = '';

  form = this.fb.group({
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    department: ['', Validators.required],
    phoneNumber: ['', Validators.required],
    dateOfBirth: ['', Validators.required],
    gender: ['Male', Validators.required],
    active: [true]
  });

  constructor(
    private fb: FormBuilder,
    private studentService: StudentService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.studentId = Number(id);
      this.pageTitle = 'Edit Student';
      this.studentService.getStudentById(this.studentId).subscribe(student => {
        this.form.patchValue(student);
      });
    }
  }

  submit(): void {
    this.errorMessage = '';
    if (this.form.invalid) {
      this.errorMessage = 'Please fill all required fields.';
      return;
    }

    const payload = this.form.value as Student;
    const request = this.studentId
      ? this.studentService.updateStudent(this.studentId, payload)
      : this.studentService.addStudent(payload);

    request.subscribe({
      next: () => this.router.navigateByUrl('/students'),
      error: (err) => {
        this.errorMessage = err?.error?.message || 'Save failed.';
      }
    });
  }
}
