# Student Management UI

This folder contains an Angular frontend for the Student Management System.

## Demo login
- Username: `admin`
- Password: `admin123`

## Run
1. Install dependencies
2. Start the Angular app on `http://localhost:4200`
3. Make sure the backend runs on `http://localhost:8080`
