CREATE DATABASE IF NOT EXISTS studentdb;

USE studentdb;

CREATE TABLE IF NOT EXISTS students (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    department VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(20) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

INSERT INTO students (first_name, last_name, email, department, phone_number, date_of_birth, gender, active)
VALUES
('Rahul', 'Sharma', 'rahul@gmail.com', 'CSE', '9876543210', '2002-08-15', 'Male', TRUE),
('Anita', 'Verma', 'anita@gmail.com', 'IT', '9123456780', '2003-01-10', 'Female', TRUE)
ON DUPLICATE KEY UPDATE email=email;
