# Student Management System

A full-stack demo project for tool demonstration using:
- Angular frontend
- Spring Boot backend
- Spring Security authentication
- MySQL database

## Features
- Login authentication
- View all students
- Add, edit, delete students
- Search students by name
- Validation and exception handling
- REST API testing with Postman

## Demo Credentials
- Username: `admin`
- Password: `admin123`

## Backend
### Run steps
1. Create MySQL database `studentdb`
2. Update `backend/src/main/resources/application.properties` if needed
3. Run Spring Boot application

### Important APIs
- `POST /api/auth/login`
- `GET /api/students`
- `GET /api/students/{id}`
- `POST /api/students`
- `PUT /api/students/{id}`
- `DELETE /api/students/{id}`

## Frontend
### Run steps
1. Open the `frontend` folder as an Angular project
2. Install dependencies
3. Run `ng serve`

## Database
The SQL script is available at:
- `backend/src/main/resources/db/studentdb.sql`

## Folder Structure
- `backend/` Spring Boot project
- `frontend/` Angular UI

## Submission Name
`YourName_StudentManagementSystem.zip`
