-- Create database and user
CREATE DATABASE IF NOT EXISTS student_portal;
USE student_portal;

-- Insert default roles
INSERT INTO roles (name, created_date, updated_date, deleted) VALUES 
('ADMIN', NOW(), NOW(), false),
('FACULTY', NOW(), NOW(), false),
('STUDENT', NOW(), NOW(), false)
ON DUPLICATE KEY UPDATE name=name;

-- Insert default admin user (password: admin123)
INSERT INTO users (username, password, email, role_id, active, created_date, updated_date, deleted) 
SELECT 'admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', 'admin@studentportal.com', id, true, NOW(), NOW(), false
FROM roles WHERE name = 'ADMIN'
ON DUPLICATE KEY UPDATE username=username;
