# API Documentation

## Base URL
- **Development**: `http://localhost:8080/api`
- **Production**: `https://api.studentportal.com/api`

## Authentication

All endpoints (except `/api/auth/login`) require JWT authentication in the request header:

```
Authorization: Bearer <your-jwt-token>
```

## Authentication Endpoints

### Login
- **Endpoint**: `POST /api/auth/login`
- **Description**: Authenticate user and receive JWT token
- **Request Body**:
```json
{
  "username": "admin",
  "password": "admin123"
}
```
- **Response**:
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "username": "admin",
  "email": "admin@studentportal.com",
  "role": "ADMIN",
  "userId": 1
}
```

## Student Endpoints

### Get All Students
- **Endpoint**: `GET /api/students`
- **Description**: Retrieve all students with pagination and search
- **Query Parameters**:
  - `page` (optional): Page number (default: 0)
  - `size` (optional): Page size (default: 10)
  - `sortBy` (optional): Sort field (default: firstName)
  - `sortDir` (optional): Sort direction (asc/desc, default: asc)
  - `keyword` (optional): Search keyword
- **Response**:
```json
{
  "content": [
    {
      "id": 1,
      "rollNumber": "2024001",
      "firstName": "John",
      "lastName": "Doe",
      "email": "john.doe@studentportal.com",
      "phone": "9876543210",
      "department": "CSE",
      "semester": 3
    }
  ],
  "pageNumber": 0,
  "pageSize": 10,
  "totalElements": 100,
  "totalPages": 10,
  "first": true,
  "last": false
}
```

### Get Student by ID
- **Endpoint**: `GET /api/students/{id}`
- **Description**: Retrieve a specific student by ID
- **Response**:
```json
{
  "id": 1,
  "rollNumber": "2024001",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@studentportal.com",
  "phone": "9876543210",
  "department": "CSE",
  "semester": 3
}
```

### Create Student
- **Endpoint**: `POST /api/students`
- **Roles Required**: ADMIN, FACULTY
- **Request Body**:
```json
{
  "rollNumber": "2024002",
  "firstName": "Jane",
  "lastName": "Smith",
  "email": "jane.smith@studentportal.com",
  "phone": "9876543211",
  "department": "CSE",
  "semester": 3
}
```

### Update Student
- **Endpoint**: `PUT /api/students/{id}`
- **Roles Required**: ADMIN, FACULTY
- **Request Body**: Same as create student

### Delete Student
- **Endpoint**: `DELETE /api/students/{id}`
- **Roles Required**: ADMIN

## Course Endpoints

### Get All Courses
- **Endpoint**: `GET /api/courses`
- **Query Parameters**: Same as students (page, size, sortBy, sortDir, keyword)
- **Response**:
```json
{
  "content": [
    {
      "id": 1,
      "courseCode": "CS101",
      "courseName": "Introduction to Computer Science",
      "credits": 3,
      "facultyName": "Dr. Smith"
    }
  ],
  "pageNumber": 0,
  "pageSize": 10,
  "totalElements": 50,
  "totalPages": 5,
  "first": true,
  "last": false
}
```

### Create Course
- **Endpoint**: `POST /api/courses`
- **Roles Required**: ADMIN, FACULTY
- **Request Body**:
```json
{
  "courseCode": "CS102",
  "courseName": "Data Structures",
  "credits": 4,
  "facultyName": "Dr. Johnson"
}
```

## Attendance Endpoints

### Get Attendance by Student
- **Endpoint**: `GET /api/attendance/student/{studentId}`
- **Description**: Retrieve attendance records for a specific student
- **Response**:
```json
[
  {
    "id": 1,
    "studentId": 1,
    "studentName": "John Doe",
    "rollNumber": "2024001",
    "courseId": 1,
    "courseCode": "CS101",
    "courseName": "Introduction to Computer Science",
    "attendancePercentage": 85.5,
    "totalClasses": 40,
    "attendedClasses": 34
  }
]
```

### Get Attendance Defaulters
- **Endpoint**: `GET /api/attendance/defaulters`
- **Roles Required**: ADMIN, FACULTY
- **Description**: Retrieve students with attendance below 75%

### Create Attendance
- **Endpoint**: `POST /api/attendance`
- **Roles Required**: ADMIN, FACULTY
- **Request Body**:
```json
{
  "studentId": 1,
  "courseId": 1,
  "attendancePercentage": 85.5,
  "totalClasses": 40,
  "attendedClasses": 34
}
```

## Marks Endpoints

### Get Marks by Student
- **Endpoint**: `GET /api/marks/student/{studentId}`
- **Description**: Retrieve marks for a specific student
- **Response**:
```json
[
  {
    "id": 1,
    "studentId": 1,
    "studentName": "John Doe",
    "rollNumber": "2024001",
    "courseId": 1,
    "courseCode": "CS101",
    "courseName": "Introduction to Computer Science",
    "score": 85.5,
    "maxScore": 100.0,
    "grade": "A",
    "examDate": "2024-06-15"
  }
]
```

### Get Student Rankings
- **Endpoint**: `GET /api/marks/rankings`
- **Roles Required**: ADMIN, FACULTY
- **Description**: Retrieve student rankings based on average scores
- **Response**:
```json
[
  {
    "id": 1,
    "rollNumber": "2024001",
    "firstName": "John",
    "lastName": "Doe",
    "department": "CSE",
    "averageScore": 88.5,
    "rank": 1,
    "totalCourses": 5
  }
]
```

### Create Marks
- **Endpoint**: `POST /api/marks`
- **Roles Required**: ADMIN, FACULTY
- **Request Body**:
```json
{
  "studentId": 1,
  "courseId": 1,
  "score": 85.5,
  "maxScore": 100.0,
  "examDate": "2024-06-15"
}
```

## Dashboard Endpoints

### Get Dashboard Summary
- **Endpoint**: `GET /api/dashboard/summary`
- **Roles Required**: ADMIN, FACULTY
- **Description**: Retrieve dashboard summary statistics
- **Response**:
```json
{
  "totalStudents": 500,
  "totalCourses": 50,
  "averageAttendance": 82.5,
  "passPercentage": 85.0,
  "totalFaculty": 25,
  "totalAnnouncements": 10
}
```

### Get Top Students
- **Endpoint**: `GET /api/dashboard/top-students?limit=10`
- **Roles Required**: ADMIN, FACULTY
- **Description**: Retrieve top performing students

### Get Low Attendance Students
- **Endpoint**: `GET /api/dashboard/low-attendance?threshold=75`
- **Roles Required**: ADMIN, FACULTY
- **Description**: Retrieve students with low attendance

### Get At-Risk Students
- **Endpoint**: `GET /api/dashboard/at-risk-students`
- **Roles Required**: ADMIN, FACULTY
- **Description**: Retrieve students at risk of failing

### Get Department Performance
- **Endpoint**: `GET /api/dashboard/department-performance`
- **Roles Required**: ADMIN, FACULTY
- **Description**: Retrieve performance statistics by department

### Get Pass/Fail Statistics
- **Endpoint**: `GET /api/dashboard/pass-fail-stats`
- **Roles Required**: ADMIN, FACULTY
- **Description**: Retrieve pass vs fail statistics

### Get Attendance Statistics
- **Endpoint**: `GET /api/dashboard/attendance-stats`
- **Roles Required**: ADMIN, FACULTY
- **Description**: Retrieve attendance statistics

## Announcement Endpoints

### Get All Announcements
- **Endpoint**: `GET /api/announcements`
- **Query Parameters**: page, size
- **Response**:
```json
{
  "content": [
    {
      "id": 1,
      "title": "Midterm Exam Schedule",
      "description": "Midterm exams will be held from June 20-25",
      "createdBy": "Admin",
      "priority": "HIGH",
      "targetAudience": "ALL"
    }
  ],
  "pageNumber": 0,
  "pageSize": 10,
  "totalElements": 20,
  "totalPages": 2,
  "first": true,
  "last": false
}
```

### Create Announcement
- **Endpoint**: `POST /api/announcements`
- **Roles Required**: ADMIN, FACULTY
- **Request Body**:
```json
{
  "title": "Holiday Notice",
  "description": "College will remain closed on June 25",
  "priority": "NORMAL",
  "targetAudience": "ALL"
}
```

## Study Material Endpoints

### Get Study Materials by Course
- **Endpoint**: `GET /api/study-materials/course/{courseId}`
- **Description**: Retrieve study materials for a specific course
- **Response**:
```json
[
  {
    "id": 1,
    "courseId": 1,
    "courseCode": "CS101",
    "courseName": "Introduction to Computer Science",
    "title": "Lecture Notes - Week 1",
    "description": "Introduction to programming concepts",
    "fileUrl": "https://example.com/files/lecture1.pdf",
    "fileType": "PDF",
    "uploadDate": "2024-06-01"
  }
]
```

### Create Study Material
- **Endpoint**: `POST /api/study-materials`
- **Roles Required**: ADMIN, FACULTY
- **Request Body**:
```json
{
  "courseId": 1,
  "title": "Assignment Guidelines",
  "description": "Guidelines for completing assignments",
  "fileUrl": "https://example.com/files/guidelines.pdf",
  "fileType": "PDF"
}
```

## Error Responses

All endpoints may return error responses in the following format:

```json
{
  "status": 400,
  "message": "Error message describing the issue",
  "error": "Bad Request",
  "timestamp": "2024-06-16T12:00:00",
  "details": ["Additional error details"]
}
```

### Common HTTP Status Codes
- `200 OK` - Request successful
- `201 Created` - Resource created successfully
- `400 Bad Request` - Invalid request data
- `401 Unauthorized` - Authentication required or invalid
- `403 Forbidden` - Insufficient permissions
- `404 Not Found` - Resource not found
- `409 Conflict` - Resource already exists
- `500 Internal Server Error` - Server error

## Rate Limiting

Currently, there is no rate limiting implemented. Consider adding rate limiting for production use.

## Pagination

Most list endpoints support pagination with the following parameters:
- `page`: Page number (0-based)
- `size`: Number of items per page
- `sortBy`: Field to sort by
- `sortDir`: Sort direction (asc/desc)

## Search

Many endpoints support keyword search:
- Students: Search by name or roll number
- Courses: Search by course code or name

## Role-Based Access Control

- **ADMIN**: Full access to all endpoints
- **FACULTY**: Access to attendance, marks, courses, and reports
- **STUDENT**: Read-only access to personal data, attendance, marks, and study materials

## Testing the API

### Using cURL

```bash
# Login
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Get students (with token)
curl -X GET http://localhost:8080/api/students \
  -H "Authorization: Bearer <your-token>"
```

### Using Swagger UI

1. Navigate to `http://localhost:8080/swagger-ui.html`
2. Click on any endpoint to expand details
3. Click "Try it out"
4. Fill in required parameters
5. Click "Execute"

## Support

For API-related issues:
- Check the [Error Responses](#error-responses) section
- Review Swagger UI for detailed endpoint information
- Contact support at support@studentportal.com
