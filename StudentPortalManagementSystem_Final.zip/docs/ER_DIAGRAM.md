# ER Diagram Summary

Core tables:
- roles
- users
- students
- courses
- student_courses
- attendance
- marks
- announcements
- study_materials
- audit_logs
