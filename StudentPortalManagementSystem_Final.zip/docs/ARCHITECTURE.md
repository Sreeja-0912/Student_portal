# Architecture

- Spring Boot backend with REST controllers, service layer, repositories, DTOs, JWT security, and global exception handling.
- Angular standalone frontend with lazy-loaded routes, functional guards, and functional interceptors.
- MySQL 8 schema with soft delete and auditing columns.
