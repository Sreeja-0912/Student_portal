# Student Portal Management System

A full-stack academic portal demo with Spring Boot, JWT authentication, Angular standalone UI, MySQL schema, Docker, Swagger, and role-based dashboards.

## Default Login
- Username: `admin`
- Password: `Admin@123`

## Run
### Backend
```bash
cd backend
mvn spring-boot:run
```

### Frontend
```bash
cd frontend
npm install
npm start
```

### Docker
```bash
docker compose up --build
```

## API Highlights
- `POST /api/auth/login`
- `POST /api/auth/register`
- `GET /api/students`
- `POST /api/students`
- `GET /api/courses`
- `POST /api/courses`
- `POST /api/attendance`
- `GET /api/dashboard/summary`

See `database/schema.sql` and `postman/StudentPortal.postman_collection.json`.
