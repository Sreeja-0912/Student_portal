import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Student } from '../models/student.models';
@Injectable({ providedIn: 'root' })
export class StudentService {
  private base = `${environment.apiUrl}/students`;
  constructor(private http: HttpClient) {}
  list() { return this.http.get<Student[]>(this.base); }
}
