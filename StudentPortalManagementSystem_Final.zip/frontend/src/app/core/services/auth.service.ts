import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { LoginRequest, LoginResponse } from '../models/auth.models';
@Injectable({ providedIn: 'root' })
export class AuthService {
  user = signal<LoginResponse | null>(null);
  constructor(private http: HttpClient) {}
  login(payload: LoginRequest) { return this.http.post<LoginResponse>(`${environment.apiUrl}/auth/login`, payload); }
}
