export interface Student { id?: number; rollNumber: string; firstName: string; lastName?: string; email: string; phone?: string; department?: string; semester?: number; }
