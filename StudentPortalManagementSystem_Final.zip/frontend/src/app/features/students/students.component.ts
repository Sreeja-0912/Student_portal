import { Component } from '@angular/core';
@Component({
  selector: 'app-students',
  standalone: true,
  template: '<h1>Students</h1><p>Paginated CRUD table and forms.</p>'
})
export class StudentsComponent {}
