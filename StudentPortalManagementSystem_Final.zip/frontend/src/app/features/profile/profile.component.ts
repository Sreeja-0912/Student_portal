import { Component } from '@angular/core';
@Component({
  selector: 'app-profile',
  standalone: true,
  template: '<h1>Profile</h1><p>Account and permissions summary.</p>'
})
export class ProfileComponent {}
