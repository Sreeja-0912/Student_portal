import { Component } from '@angular/core';
@Component({
  selector: 'app-courses',
  standalone: true,
  template: '<h1>Courses</h1><p>Course list and admin actions.</p>'
})
export class CoursesComponent {}
