import { Component } from '@angular/core';
@Component({
  selector: 'app-attendance',
  standalone: true,
  template: '<h1>Attendance</h1><p>Record attendance and view defaulters.</p>'
})
export class AttendanceComponent {}
