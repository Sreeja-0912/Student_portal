import { Component } from '@angular/core';
@Component({
  selector: 'app-dashboard',
  standalone: true,
  template: '<h1>Dashboard</h1><p>Summary cards and charts will appear here.</p>'
})
export class DashboardComponent {}
