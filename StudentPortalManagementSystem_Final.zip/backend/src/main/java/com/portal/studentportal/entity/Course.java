package com.portal.studentportal.entity;
import jakarta.persistence.*; import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name="courses")
public class Course extends BaseEntity {
  @Column(name="course_code", unique=true, nullable=false) private String courseCode;
  @Column(name="course_name", nullable=false) private String courseName;
  @Column(nullable=false) private Integer credits;
  @Column(name="faculty_name") private String facultyName;
}
