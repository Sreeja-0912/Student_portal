package com.portal.studentportal.dto.course;
import lombok.Builder; import lombok.Data;
@Data @Builder public class CourseResponse { private Long id; private String courseCode; private String courseName; private Integer credits; private String facultyName; }
