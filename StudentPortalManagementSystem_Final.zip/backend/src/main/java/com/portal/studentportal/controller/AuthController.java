package com.portal.studentportal.controller;
import com.portal.studentportal.dto.auth.*; import com.portal.studentportal.service.AuthService; import jakarta.validation.Valid; import org.springframework.http.ResponseEntity; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/auth")
public class AuthController {
  private final AuthService authService;
  public AuthController(AuthService authService) { this.authService = authService; }
  @PostMapping("/login") public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) { return ResponseEntity.ok(authService.login(request)); }
  @PostMapping("/register") public ResponseEntity<String> register(@Valid @RequestBody RegisterRequest request) { return ResponseEntity.status(201).body(authService.register(request)); }
}
