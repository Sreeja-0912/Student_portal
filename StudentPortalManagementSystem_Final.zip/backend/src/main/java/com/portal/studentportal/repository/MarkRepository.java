package com.portal.studentportal.repository;
import com.portal.studentportal.entity.Mark;
import org.springframework.data.jpa.repository.JpaRepository;
public interface MarkRepository extends JpaRepository<Mark, Long> {}
