package com.portal.studentportal.service.impl;
import com.portal.studentportal.dto.auth.*; import com.portal.studentportal.entity.*; import com.portal.studentportal.repository.*; import com.portal.studentportal.security.JwtService; import com.portal.studentportal.service.AuthService; import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.stereotype.Service;
@Service
public class AuthServiceImpl implements AuthService {
  private final UserRepository userRepository; private final RoleRepository roleRepository; private final PasswordEncoder passwordEncoder; private final JwtService jwtService;
  public AuthServiceImpl(UserRepository userRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder, JwtService jwtService) { this.userRepository = userRepository; this.roleRepository = roleRepository; this.passwordEncoder = passwordEncoder; this.jwtService = jwtService; }
  @Override public LoginResponse login(LoginRequest request) {
    User user = userRepository.findByUsernameAndDeletedFalse(request.getUsername()).orElseThrow(() -> new RuntimeException("Invalid credentials"));
    if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) throw new RuntimeException("Invalid credentials");
    String role = user.getRole() != null ? user.getRole().getName() : "ADMIN";
    return LoginResponse.builder().token(jwtService.generateToken(user.getUsername(), role)).username(user.getUsername()).role(role).build();
  }
  @Override public String register(RegisterRequest request) {
    Role role = roleRepository.findByNameIgnoreCase(request.getRole()).orElseThrow(() -> new RuntimeException("Role not found"));
    userRepository.save(User.builder().username(request.getUsername()).password(passwordEncoder.encode(request.getPassword())).email(request.getEmail()).role(role).active(true).build());
    return "User registered successfully";
  }
}
