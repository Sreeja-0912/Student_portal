package com.portal.studentportal.repository;
import com.portal.studentportal.entity.Attendance;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {}
