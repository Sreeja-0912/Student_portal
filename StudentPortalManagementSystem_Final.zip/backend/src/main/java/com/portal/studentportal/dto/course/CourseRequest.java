package com.portal.studentportal.dto.course;
import jakarta.validation.constraints.*; import lombok.Data;
@Data public class CourseRequest { @NotBlank private String courseCode; @NotBlank private String courseName; @NotNull private Integer credits; private String facultyName; }
