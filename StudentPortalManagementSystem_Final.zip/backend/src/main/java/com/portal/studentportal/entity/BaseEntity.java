package com.portal.studentportal.entity;
import jakarta.persistence.*;
import lombok.Getter; import lombok.Setter; import lombok.experimental.SuperBuilder;
import org.springframework.data.annotation.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;
@Getter @Setter @SuperBuilder @MappedSuperclass @EntityListeners(AuditingEntityListener.class)
public abstract class BaseEntity {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @CreatedDate private LocalDateTime createdDate;
  @LastModifiedDate private LocalDateTime updatedDate;
  @CreatedBy private String createdBy;
  @LastModifiedBy private String updatedBy;
  private boolean deleted = false;
}
