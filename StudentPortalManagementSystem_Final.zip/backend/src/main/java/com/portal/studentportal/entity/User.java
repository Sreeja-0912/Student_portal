package com.portal.studentportal.entity;
import jakarta.persistence.*; import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name="users")
public class User extends BaseEntity {
  @Column(unique=true, nullable=false) private String username;
  @Column(nullable=false) private String password;
  @Column(unique=true, nullable=false) private String email;
  @ManyToOne(fetch = FetchType.EAGER) @JoinColumn(name="role_id") private Role role;
  private boolean active = true;
}
