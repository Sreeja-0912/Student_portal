package com.portal.studentportal.service.impl;
import com.portal.studentportal.dto.student.*; import com.portal.studentportal.entity.Student; import com.portal.studentportal.exception.ResourceNotFoundException; import com.portal.studentportal.repository.StudentRepository; import com.portal.studentportal.service.StudentService; import org.springframework.data.domain.*; import org.springframework.stereotype.Service;
@Service
public class StudentServiceImpl implements StudentService {
  private final StudentRepository repository;
  public StudentServiceImpl(StudentRepository repository) { this.repository = repository; }
  @Override public Page<StudentResponse> list(int page, int size, String sortBy, String direction, String search) {
    return repository.findAll(PageRequest.of(page, size, Sort.by(Sort.Direction.fromString(direction), sortBy))).map(this::toResponse);
  }
  @Override public StudentResponse get(Long id) { return toResponse(repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student not found"))); }
  @Override public StudentResponse create(StudentRequest request) { return toResponse(repository.save(Student.builder().rollNumber(request.getRollNumber()).firstName(request.getFirstName()).lastName(request.getLastName()).email(request.getEmail()).phone(request.getPhone()).department(request.getDepartment()).semester(request.getSemester()).build())); }
  @Override public StudentResponse update(Long id, StudentRequest request) { Student s = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student not found")); s.setRollNumber(request.getRollNumber()); s.setFirstName(request.getFirstName()); s.setLastName(request.getLastName()); s.setEmail(request.getEmail()); s.setPhone(request.getPhone()); s.setDepartment(request.getDepartment()); s.setSemester(request.getSemester()); return toResponse(repository.save(s)); }
  @Override public void softDelete(Long id) { Student s = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student not found")); s.setDeleted(true); repository.save(s); }
  private StudentResponse toResponse(Student s) { return StudentResponse.builder().id(s.getId()).rollNumber(s.getRollNumber()).firstName(s.getFirstName()).lastName(s.getLastName()).email(s.getEmail()).phone(s.getPhone()).department(s.getDepartment()).semester(s.getSemester()).build(); }
}
