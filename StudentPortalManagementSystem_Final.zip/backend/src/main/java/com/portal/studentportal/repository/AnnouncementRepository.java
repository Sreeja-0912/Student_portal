package com.portal.studentportal.repository;
import com.portal.studentportal.entity.Announcement;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AnnouncementRepository extends JpaRepository<Announcement, Long> {}
