package com.portal.studentportal.service;
import com.portal.studentportal.dto.course.*; import org.springframework.data.domain.Page;
public interface CourseService { Page<CourseResponse> list(int page, int size, String search); CourseResponse create(CourseRequest request); }
