package com.portal.studentportal.controller;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/attendance")
public class AttendanceController { @PostMapping public String create() { return "Attendance recorded"; } }
