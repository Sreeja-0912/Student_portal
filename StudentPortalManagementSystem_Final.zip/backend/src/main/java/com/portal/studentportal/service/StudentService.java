package com.portal.studentportal.service;
import com.portal.studentportal.dto.student.*; import org.springframework.data.domain.Page;
public interface StudentService { Page<StudentResponse> list(int page, int size, String sortBy, String direction, String search); StudentResponse get(Long id); StudentResponse create(StudentRequest request); StudentResponse update(Long id, StudentRequest request); void softDelete(Long id); }
