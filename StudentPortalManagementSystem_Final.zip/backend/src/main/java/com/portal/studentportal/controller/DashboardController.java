package com.portal.studentportal.controller;
import com.portal.studentportal.dto.dashboard.SummaryResponse; import com.portal.studentportal.service.DashboardService; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/dashboard")
public class DashboardController {
  private final DashboardService service;
  public DashboardController(DashboardService service) { this.service = service; }
  @GetMapping("/summary") public SummaryResponse summary() { return service.summary(); }
}
