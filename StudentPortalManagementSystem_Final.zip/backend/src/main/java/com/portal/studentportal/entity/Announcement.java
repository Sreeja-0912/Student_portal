package com.portal.studentportal.entity;
import jakarta.persistence.*; import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name="announcements")
public class Announcement extends BaseEntity {
  @Column(nullable=false, length=200) private String title;
  @Column(nullable=false, length=2000) private String description;
  @Column(name="created_by_name") private String createdByName;
}
