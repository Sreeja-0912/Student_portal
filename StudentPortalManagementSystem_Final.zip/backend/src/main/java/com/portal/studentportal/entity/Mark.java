package com.portal.studentportal.entity;
import jakarta.persistence.*; import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name="marks")
public class Mark extends BaseEntity {
  @ManyToOne(fetch = FetchType.LAZY) private Student student;
  @ManyToOne(fetch = FetchType.LAZY) private Course course;
  @Column(nullable=false) private Double score;
}
