package com.portal.studentportal.entity;
import jakarta.persistence.*; import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name="audit_logs")
public class AuditLog extends BaseEntity {
  @Column(nullable=false, length=200) private String action;
  @Column(length=100) private String username;
}
