package com.portal.studentportal.repository;
import com.portal.studentportal.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface StudentRepository extends JpaRepository<Student, Long> {
  List<Student> findByDeletedFalse();
  Optional<Student> findByRollNumberAndDeletedFalse(String rollNumber);
  Optional<Student> findByEmailAndDeletedFalse(String email);
}
