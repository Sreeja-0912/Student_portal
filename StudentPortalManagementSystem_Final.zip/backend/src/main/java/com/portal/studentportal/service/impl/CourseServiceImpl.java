package com.portal.studentportal.service.impl;
import com.portal.studentportal.dto.course.*; import com.portal.studentportal.entity.Course; import com.portal.studentportal.repository.CourseRepository; import com.portal.studentportal.service.CourseService; import org.springframework.data.domain.*; import org.springframework.stereotype.Service;
@Service
public class CourseServiceImpl implements CourseService {
  private final CourseRepository repository;
  public CourseServiceImpl(CourseRepository repository) { this.repository = repository; }
  @Override public Page<CourseResponse> list(int page, int size, String search) { return repository.findAll(PageRequest.of(page, size)).map(c -> CourseResponse.builder().id(c.getId()).courseCode(c.getCourseCode()).courseName(c.getCourseName()).credits(c.getCredits()).facultyName(c.getFacultyName()).build()); }
  @Override public CourseResponse create(CourseRequest request) { Course c = repository.save(Course.builder().courseCode(request.getCourseCode()).courseName(request.getCourseName()).credits(request.getCredits()).facultyName(request.getFacultyName()).build()); return CourseResponse.builder().id(c.getId()).courseCode(c.getCourseCode()).courseName(c.getCourseName()).credits(c.getCredits()).facultyName(c.getFacultyName()).build(); }
}
