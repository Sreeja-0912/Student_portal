package com.portal.studentportal.security;
import io.jsonwebtoken.*; import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value; import org.springframework.stereotype.Service;
import java.security.Key; import java.util.Base64; import java.util.Date; import java.util.Map;
@Service
public class JwtService {
  @Value("${app.jwt.secret}") private String secret;
  @Value("${app.jwt.expiration}") private long expiration;
  private Key key() { return Keys.hmacShaKeyFor(Base64.getDecoder().decode(secret)); }
  public String generateToken(String username, String role) {
    return Jwts.builder().subject(username).claims(Map.of("role", role)).issuedAt(new Date()).expiration(new Date(System.currentTimeMillis() + expiration)).signWith(key()).compact();
  }
  public String extractUsername(String token) { return Jwts.parser().verifyWith((javax.crypto.SecretKey) key()).build().parseSignedClaims(token).getPayload().getSubject(); }
  public String extractRole(String token) { return (String) Jwts.parser().verifyWith((javax.crypto.SecretKey) key()).build().parseSignedClaims(token).getPayload().get("role"); }
  public boolean isValid(String token) { try { Jwts.parser().verifyWith((javax.crypto.SecretKey) key()).build().parseSignedClaims(token); return true; } catch (Exception ex) { return false; } }
}
