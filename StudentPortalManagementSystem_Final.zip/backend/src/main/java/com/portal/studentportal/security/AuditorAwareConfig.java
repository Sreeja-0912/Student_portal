package com.portal.studentportal.security;
import org.springframework.context.annotation.*; import org.springframework.data.domain.AuditorAware;
import java.util.Optional;
@Configuration
public class AuditorAwareConfig {
  @Bean AuditorAware<String> auditorAware() { return () -> Optional.of("system"); }
}
