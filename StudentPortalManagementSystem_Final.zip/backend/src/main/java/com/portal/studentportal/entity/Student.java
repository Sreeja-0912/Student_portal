package com.portal.studentportal.entity;
import jakarta.persistence.*; import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name="students")
public class Student extends BaseEntity {
  @Column(name="roll_number", unique=true, nullable=false) private String rollNumber;
  @Column(name="first_name", nullable=false) private String firstName;
  @Column(name="last_name") private String lastName;
  @Column(unique=true, nullable=false) private String email;
  private String phone;
  private String department;
  private Integer semester;
  @OneToOne @JoinColumn(name="user_id") private User user;
}
