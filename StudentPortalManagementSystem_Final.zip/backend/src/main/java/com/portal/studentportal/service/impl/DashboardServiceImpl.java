package com.portal.studentportal.service.impl;
import com.portal.studentportal.dto.dashboard.SummaryResponse; import com.portal.studentportal.repository.CourseRepository; import com.portal.studentportal.repository.StudentRepository; import com.portal.studentportal.service.DashboardService; import org.springframework.stereotype.Service;
@Service
public class DashboardServiceImpl implements DashboardService {
  private final StudentRepository studentRepository; private final CourseRepository courseRepository;
  public DashboardServiceImpl(StudentRepository studentRepository, CourseRepository courseRepository) { this.studentRepository = studentRepository; this.courseRepository = courseRepository; }
  @Override public SummaryResponse summary() { return SummaryResponse.builder().totalStudents(studentRepository.count()).totalCourses(courseRepository.count()).averageAttendance(0.0).passPercentage(0.0).build(); }
}
