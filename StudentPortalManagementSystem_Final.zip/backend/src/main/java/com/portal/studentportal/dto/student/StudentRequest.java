package com.portal.studentportal.dto.student;
import jakarta.validation.constraints.*; import lombok.Data;
@Data public class StudentRequest { @NotBlank private String rollNumber; @NotBlank private String firstName; private String lastName; @Email @NotBlank private String email; private String phone; private String department; private Integer semester; }
