package com.portal.studentportal.service;
import com.portal.studentportal.dto.auth.*;
public interface AuthService { LoginResponse login(LoginRequest request); String register(RegisterRequest request); }
