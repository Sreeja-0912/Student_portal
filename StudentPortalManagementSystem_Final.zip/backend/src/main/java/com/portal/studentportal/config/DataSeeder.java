package com.portal.studentportal.config;
import com.portal.studentportal.entity.*; import com.portal.studentportal.repository.*; import org.springframework.boot.CommandLineRunner; import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.stereotype.Component;
@Component
public class DataSeeder implements CommandLineRunner {
  private final RoleRepository roleRepository; private final UserRepository userRepository; private final PasswordEncoder passwordEncoder;
  public DataSeeder(RoleRepository roleRepository, UserRepository userRepository, PasswordEncoder passwordEncoder) { this.roleRepository = roleRepository; this.userRepository = userRepository; this.passwordEncoder = passwordEncoder; }
  @Override public void run(String... args) {
    Role admin = roleRepository.findByNameIgnoreCase("ADMIN").orElseGet(() -> roleRepository.save(Role.builder().name("ADMIN").build()));
    roleRepository.findByNameIgnoreCase("FACULTY").orElseGet(() -> roleRepository.save(Role.builder().name("FACULTY").build()));
    roleRepository.findByNameIgnoreCase("STUDENT").orElseGet(() -> roleRepository.save(Role.builder().name("STUDENT").build()));
    userRepository.findByUsername("admin").orElseGet(() -> userRepository.save(User.builder().username("admin").email("admin@portal.com").password(passwordEncoder.encode("Admin@123")).role(admin).active(true).build()));
  }
}
