package com.portal.studentportal.dto.auth;
import jakarta.validation.constraints.*; import lombok.Data;
@Data public class RegisterRequest { @NotBlank private String username; @NotBlank private String password; @Email @NotBlank private String email; @NotBlank private String role; }
