package com.portal.studentportal.config;
import io.swagger.v3.oas.models.OpenAPI; import org.springframework.context.annotation.*;
@Configuration public class OpenApiConfig { @Bean OpenAPI openAPI() { return new OpenAPI(); } }
