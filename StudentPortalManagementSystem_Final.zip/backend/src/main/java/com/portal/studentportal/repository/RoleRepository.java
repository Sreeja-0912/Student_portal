package com.portal.studentportal.repository;
import com.portal.studentportal.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface RoleRepository extends JpaRepository<Role, Long> {
  Optional<Role> findByNameIgnoreCase(String name);
}
