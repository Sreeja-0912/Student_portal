package com.portal.studentportal.dto.student;
import lombok.Builder; import lombok.Data;
@Data @Builder public class StudentResponse { private Long id; private String rollNumber; private String firstName; private String lastName; private String email; private String phone; private String department; private Integer semester; }
