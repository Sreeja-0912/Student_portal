package com.portal.studentportal.repository;
import com.portal.studentportal.entity.StudyMaterial;
import org.springframework.data.jpa.repository.JpaRepository;
public interface StudyMaterialRepository extends JpaRepository<StudyMaterial, Long> {}
