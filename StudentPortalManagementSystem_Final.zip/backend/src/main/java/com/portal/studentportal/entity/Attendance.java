package com.portal.studentportal.entity;
import jakarta.persistence.*; import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name="attendance")
public class Attendance extends BaseEntity {
  @ManyToOne(fetch = FetchType.LAZY) private Student student;
  @ManyToOne(fetch = FetchType.LAZY) private Course course;
  @Column(name="attendance_percentage", nullable=false) private Double attendancePercentage;
}
