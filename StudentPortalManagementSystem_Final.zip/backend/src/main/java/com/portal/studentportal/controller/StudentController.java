package com.portal.studentportal.controller;
import com.portal.studentportal.dto.student.*; import com.portal.studentportal.service.StudentService; import jakarta.validation.Valid; import org.springframework.data.domain.Page; import org.springframework.http.*; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/students")
public class StudentController {
  private final StudentService service;
  public StudentController(StudentService service) { this.service = service; }
  @GetMapping public Page<StudentResponse> list(@RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="10") int size, @RequestParam(defaultValue="id") String sortBy, @RequestParam(defaultValue="ASC") String direction, @RequestParam(defaultValue="") String search) { return service.list(page, size, sortBy, direction, search); }
  @GetMapping("/{id}") public StudentResponse get(@PathVariable Long id) { return service.get(id); }
  @PostMapping public ResponseEntity<StudentResponse> create(@Valid @RequestBody StudentRequest request) { return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request)); }
  @PutMapping("/{id}") public StudentResponse update(@PathVariable Long id, @Valid @RequestBody StudentRequest request) { return service.update(id, request); }
  @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id) { service.softDelete(id); return ResponseEntity.noContent().build(); }
}
