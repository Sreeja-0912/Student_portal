package com.portal.studentportal.service;
import com.portal.studentportal.dto.dashboard.SummaryResponse;
public interface DashboardService { SummaryResponse summary(); }
