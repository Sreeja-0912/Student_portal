package com.portal.studentportal.repository;
import com.portal.studentportal.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface CourseRepository extends JpaRepository<Course, Long> {
  List<Course> findByDeletedFalse();
}
