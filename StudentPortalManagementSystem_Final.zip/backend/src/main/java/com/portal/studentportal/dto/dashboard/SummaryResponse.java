package com.portal.studentportal.dto.dashboard;
import lombok.Builder; import lombok.Data;
@Data @Builder public class SummaryResponse { private long totalStudents; private long totalCourses; private double averageAttendance; private double passPercentage; }
