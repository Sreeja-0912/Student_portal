package com.portal.studentportal.controller;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/audit-logs")
public class AuditLogController { @GetMapping public String list() { return "[]"; } }
