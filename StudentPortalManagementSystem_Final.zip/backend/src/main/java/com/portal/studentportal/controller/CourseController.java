package com.portal.studentportal.controller;
import com.portal.studentportal.dto.course.*; import com.portal.studentportal.service.CourseService; import jakarta.validation.Valid; import org.springframework.data.domain.Page; import org.springframework.http.*; import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/courses")
public class CourseController {
  private final CourseService service;
  public CourseController(CourseService service) { this.service = service; }
  @GetMapping public Page<CourseResponse> list(@RequestParam(defaultValue="0") int page, @RequestParam(defaultValue="10") int size, @RequestParam(defaultValue="") String search) { return service.list(page, size, search); }
  @PostMapping public ResponseEntity<CourseResponse> create(@Valid @RequestBody CourseRequest request) { return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request)); }
}
