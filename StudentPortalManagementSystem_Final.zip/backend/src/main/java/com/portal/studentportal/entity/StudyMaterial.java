package com.portal.studentportal.entity;
import jakarta.persistence.*; import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity @Table(name="study_materials")
public class StudyMaterial extends BaseEntity {
  @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name="course_id") private Course course;
  @Column(nullable=false, length=200) private String title;
  @Column(name="file_url", nullable=false, length=500) private String fileUrl;
}
