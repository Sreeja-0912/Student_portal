CREATE DATABASE IF NOT EXISTS student_portal;
USE student_portal;

CREATE TABLE roles (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(30) UNIQUE NOT NULL
);

CREATE TABLE users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  role_id BIGINT,
  active BOOLEAN DEFAULT TRUE,
  created_date DATETIME,
  updated_date DATETIME,
  created_by VARCHAR(100),
  updated_by VARCHAR(100),
  deleted BOOLEAN DEFAULT FALSE,
  CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE TABLE students (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  roll_number VARCHAR(50) UNIQUE NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100),
  email VARCHAR(150) UNIQUE NOT NULL,
  phone VARCHAR(20),
  department VARCHAR(100),
  semester INT,
  user_id BIGINT,
  created_date DATETIME,
  updated_date DATETIME,
  created_by VARCHAR(100),
  updated_by VARCHAR(100),
  deleted BOOLEAN DEFAULT FALSE
);

INSERT INTO roles(name) VALUES ('ADMIN'), ('FACULTY'), ('STUDENT');
